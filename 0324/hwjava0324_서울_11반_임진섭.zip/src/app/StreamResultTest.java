package app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import virus.Virus;

public class StreamResultTest {

	public static void main(String[] args) {
		
		Integer[] intArray = { 2, 4, 6, 8, 10 };
		// #1 count
		{
			Stream<Integer> stream = Arrays.stream(intArray);
			System.out.println("stream count : " + stream.count());
		}
		
		// #2 min
		{
			Stream<Integer> stream = Arrays.stream(intArray);
			Integer min = stream.min( (n1, n2) -> { return n1 - n2;}).get();
			System.out.println("stream min : " + min);
		}
		
		// #3 max
		{
			Stream<Integer> stream = Arrays.stream(intArray);
			Integer max = stream.max( (n1, n2) -> { return n1 - n2;}).get();
			System.out.println("stream max : " + max);
		}
		
		// #4 match - allMatch 
		{
			Stream<Integer> stream = Arrays.stream(intArray);

			if( stream.allMatch( n -> { return n % 2 == 0 ; } ) ) {
				System.out.println("all match !!");
			}
		}
	}

	public static void print(Stream<?> stream) {
		// Stream forEach with functional interface consumer
		stream.forEach( a -> System.out.print(a + " "));
		System.out.println();
	}
}
