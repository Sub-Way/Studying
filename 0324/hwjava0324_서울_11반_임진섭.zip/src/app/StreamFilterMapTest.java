package app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;

import virus.Virus;

public class StreamFilterMapTest {

	public static void main(String[] args) {
		// #1 filtering - distinct()
		{
			String[] strArray = {"A", "B", "C", "B", "D", "C"};
			Stream<String> stream = Arrays.stream(strArray);

			Stream<String> streamNew = stream.distinct();
			print(streamNew);
			// print(stream); //java.lang.IllegalStateException: stream has already been operated upon or closed
		}
		
		// #2 filtering - filter() with Predicate
		{
			Integer[] intArray = { 1, 2, 3, 4, 5 };
			Stream<Integer> stream = Arrays.stream(intArray);

			Stream<Integer> streamNew = stream.filter( (n)-> { return n > 2;});
			print(streamNew);
		}
		
		// #3 Cut - limit()
		{
			Integer[] intArray = { 1, 2, 3, 4, 5 };
			Stream<Integer> stream = Arrays.stream(intArray);

			Stream<Integer> streamNew = stream.limit(3);
			print(streamNew);
		}
		
		// #4 Cut - skip()
		{
			Integer[] intArray = { 1, 2, 3, 4, 5 };
			Stream<Integer> stream = Arrays.stream(intArray);

			Stream<Integer> streamNew = stream.skip(3);
			print(streamNew);
		}
		
		// #5 Sort - sorted()
		{
			Integer[] intArray = { 4, 3, 5, 1, 2 };
			Stream<Integer> stream = Arrays.stream(intArray);

			Stream<Integer> streamNew = stream.sorted();
			print(streamNew);
		}
		
		// #6 Sort - sorted(Comparator) customize it like below desc ordering
		{
			Integer[] intArray = { 4, 3, 5, 1, 2 };
			Stream<Integer> stream = Arrays.stream(intArray);

			Stream<Integer> streamNew = stream.sorted( (n1, n2) -> { return n2 - n1;} );
			print(streamNew);
		}
		
		// #7 mapping - map() 1:1
		{
			Integer[] intArray = { 4, 3, 5, 1, 2 };
			Stream<Integer> stream = Arrays.stream(intArray);
			Stream<Integer> streamNew = stream.map( n -> n * 10 );
			print(streamNew);
		}
		
		// #8 mapping - map() 1:1
		{
			Virus[] virusArray = { new Virus("V1", 10), new Virus("V2", 20), new Virus("V3", 30) };
			Stream<Virus> stream = Arrays.stream(virusArray);
			Stream<String> streamNew = stream.map( virus -> virus.getName() );
			print(streamNew);
		}
		
		// #9 chaining
		{
			Virus[] virusArray = { new Virus("V1", 10), new Virus("V2", 20), new Virus("V3", 30) };
			Stream<String> stream = Arrays.stream(virusArray).filter(v -> {return v.getLevel() >= 20;} ).map( virus -> virus.getName() );
			print(stream);
		}
	}

	public static void print(Stream<?> stream) {
		// Stream forEach with functional interface consumer
		stream.forEach( a -> System.out.print(a + " "));
		System.out.println();
	}
}
