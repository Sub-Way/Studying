package virus;

public class Cell {
	public int power = 300;
}

