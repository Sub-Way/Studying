import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class hwgraph01_서울_11반_임진섭 {
	static int[] parents;
	static int[] rank;
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");
		int V = Integer.parseInt(st.nextToken()); // 정점의 개수
		int E = Integer.parseInt(st.nextToken()); // 간선의 개수
		Edge[] arr = new Edge[E];

		for (int i = 0; i < E; i++) {
			st = new StringTokenizer(br.readLine(), " ");
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			int c = Integer.parseInt(st.nextToken());
			arr[i] = new Edge(a-1, b-1, c);
		}
		
		Arrays.sort(arr);
		
		parents = new int[V];
		rank = new int[V];
		for (int i = 0; i < parents.length; i++) {
			makeSet(i);
		}

		int cnt = 0; // 선택된 간선의 개수
		long MST = 0; // 최소 신장 트리의 가중치의 합

		for (int i = 0; i < arr.length; i++) { // 간선을 정렬해 놓은 순서대로 검토
			int px = findSet(arr[i].a);
			int py = findSet(arr[i].b);
			if (px == py)// 사이클이 생기면 안됨, 대표자가 다르면
				continue;
			// 두 정점을 같은 집합으로 합침
			union(px, py);
			MST += arr[i].c;
			cnt++;
			if (cnt == V - 1) {
				break;
			}
		}
		
		System.out.println(MST);
		
	} // end of main

	static void makeSet(int x) {
		parents[x] = x;
	}

	static int findSet(int x) {
		if (parents[x] == x) {
			return x;
		} else {
			parents[x] = findSet(parents[x]);
			return parents[x];
		}
	}

	static void union(int x, int y) {
		if (rank[x] > rank[y]) {
			parents[y] = x;
		} else {
			parents[x] = y;
			if (rank[x] == rank[y]) {
				rank[y]++;
			}
		}
	}
	
	public static class Edge implements Comparable<Edge>{
		int a;
		int b;
		long c;
		
		Edge(int a, int b, long c){
			this.a = a;
			this.b = b;
			this.c = c;
		}

		@Override
		public int compareTo(Edge o) {
			return Long.compare(c, o.c);
		}
	}
	
} // end of class