CREATE TABLE EMP
(EMPNO int(4) PRIMARY KEY,
ENAME VARCHAR(10),
JOB VARCHAR(9),
MGR int(4),
HIREDATE DATE,
SAL decimal(7,2),
COMM decimal(7,2),
DEPTNO int(2));
INSERT INTO EMP VALUES
(7369,'SMITH','CLERK',7902,cast('2010-10-19' as date),800,NULL,20);
INSERT INTO EMP VALUES
(7499,'ALLEN','SALESMAN',7698,cast('2000-10-19' as date),1600,300,30);
INSERT INTO EMP VALUES
(7446,'JINSUB','MANAGER',7698,cast('2014-03-11' as date),2000,300,30);

select * from emp where HIREDATE like '2014%';

select * from emp where ENAME like '%S%';

select * from emp where COMM is null;

select ename 이름, deptno 부서번호, sal 급여, (sal*12)+(sal*1.5) 연봉 from emp where deptno = 30;

select ename 이름, sal 급여, sal*0.15 경조비 from emp where sal >= 2000;
