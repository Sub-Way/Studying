package app;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;

import person.Patient;

public class NetworkHttpServerPatient {
	
	public static void main(String[] args) throws IOException {

		Patient p1 = new Patient("김철수", 42, "010-1111-1111", "호흡곤란", "001", true);
		Patient p2 = new Patient("김민아", 30, "010-2222-2222", "과음", "901", true);
		Patient p3 = new Patient("박지성", 30, "010-3232-9834", "골절", "601", true);
		Patient p4 = new Patient("손흥민", 30, "010-7777-1253", "감기", "301", true);
		
		// 병원 Collection
		Set<Patient> patientList = new HashSet<Patient>();
		patientList.add(p1);
		patientList.add(p2);
		patientList.add(p3);
		patientList.add(p4);
				
		StringBuilder sb = new StringBuilder();
		sb.append("<html><body><h2>병원 정보</h2><table style='border: 1px solid green;'>");
		for( Patient p : patientList ) {
			StringBuilder name = new StringBuilder();
			name.append(p.getName());
			name.replace(1, name.length(), "XX");
			
			StringBuilder phone = new StringBuilder();
			phone.append(p.getPhone());
			phone.replace(9, phone.length(), "XXXX");
			
			sb.append("<tr style='border: 1px solid green;'><td>").append(name.toString()).append("</td><td>").append(phone.toString()).append("</td></tr>");
		}
		sb.append("</table></body></html>");
		String html = sb.toString();
		
		try (ServerSocket ss = new ServerSocket(8000)) {
			System.out.println("[Patient Info Server is ready]");
			
			while (true) {
				try ( Socket socket = ss.accept() ) {

					BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));

					bw.write("HTTP/1.1 200 OK \r\n");
					bw.write("Content-Type: text/html;charset=utf-8\r\n");
					bw.write("Content-Length: " + html.length() + "\r\n");
					bw.write("\r\n");
					bw.write(html);
					bw.write("\r\n");
	                bw.flush();

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
