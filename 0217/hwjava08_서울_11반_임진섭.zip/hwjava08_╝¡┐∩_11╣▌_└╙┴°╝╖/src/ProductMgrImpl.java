import java.util.ArrayList;
import java.util.Scanner;

public class ProductMgrImpl implements IProductMgr {
	ArrayList<Product> product = new ArrayList<>();
	static Scanner sc = new Scanner(System.in);

	@Override
	public void inputTv(TV tv) {
		product.add(tv);
	}

	@Override
	public void inputRef(Refigerator ref) {
		product.add(ref);
	}

	@Override
	public void searchAll() {
		Refigerator ref;
		TV tv;
		for (int i = 0; i < product.size(); i++) {
			if ((product.get(i) instanceof Refigerator)) {
				ref = (Refigerator) product.get(i);
				System.out.println(ref.toString());
			}
			else if ((product.get(i) instanceof TV)) {
				tv = (TV) product.get(i);
				System.out.println(tv.toString());
			}
		}
	}

	@Override
	public void searchSerial(String serial) {
		Refigerator ref;
		TV tv;
		for (int i = 0; i < product.size(); i++) {
			if ((product.get(i) instanceof Refigerator)) {
				ref = (Refigerator) product.get(i);
				if(ref.getSerial().equals(serial))
					System.out.println(ref.toString());
			}
			else if ((product.get(i) instanceof TV)) {
				tv = (TV) product.get(i);
				if(tv.getSerial().equals(serial))
					System.out.println(tv.toString());
			}
		}
	}

	@Override
	public void searchTitle(String title) {
		Refigerator ref;
		TV tv;
		for (int i = 0; i < product.size(); i++) {
			if ((product.get(i) instanceof Refigerator)) {
				ref = (Refigerator) product.get(i);
				if(ref.getTitle().equals(title))
					System.out.println(ref.toString());
			}
			else if ((product.get(i) instanceof TV)) {
				tv = (TV) product.get(i);
				if(tv.getTitle().equals(title))
					System.out.println(tv.toString());
			}
		}
	}

	@Override
	public void searchTv() {
		for (int i = 0; i < product.size(); i++) {
			if (!(product.get(i) instanceof Refigerator)) {
				System.out.println(product.get(i).toString());
			}
		}
	}

	@Override
	public void searchRef() {
		for (int i = 0; i < product.size(); i++) {
			if (!(product.get(i) instanceof TV)) {
				System.out.println(product.get(i).toString());
			}
		}
	}

	@Override
	public void searchVolumeRef() {
		Refigerator ref;
		for (int i = 0; i < product.size(); i++) {
			if (product.get(i) instanceof Refigerator) {
				ref = (Refigerator) product.get(i);
				if (ref.getVolume() >= 400)
					System.out.println(ref.toString());
			}
		}
	}

	@Override
	public void searchSizeTv() {
		TV tv;
		for (int i = 0; i < product.size(); i++) {
			if (product.get(i) instanceof TV) {
				tv = (TV) product.get(i);
				if (tv.getInch() >= 50)
					System.out.println(tv.toString());
			}
		}

	}

	@Override
	public void changeInfo() {
		System.out.print("변경할 Serial 입력 : ");
		String serial = sc.next();
		System.out.print("변경할 가격 입력 : ");
		int price = sc.nextInt();
		for (int i = 0; i < product.size(); i++) {
			if (product.get(i).serial.equals(serial)) {
				product.get(i).price = price;
			}
		}
	}

	@Override
	public void removeItem() {
		System.out.print("삭제할 Serial 입력 : ");
		String serial = sc.next();
		for (int i = 0; i < product.size(); i++) {
			if (product.get(i).getSerial().equals(serial))
				product.remove(i);
		}
		System.out.println("성공적으로 삭제되었습니다.");

	}

	@Override
	public void priceAll() {
		int sum = 0;
		for (int i = 0; i < product.size(); i++) {
			sum = sum + (product.get(i).getPrice() * product.get(i).getQuantity());
		}
		System.out.println("전체 재고 상품 금액 : " + sum);

	}

}
