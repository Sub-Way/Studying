
public interface IProductMgr {
	void inputTv(TV tv);
	
	void inputRef(Refigerator ref);
	
	void searchAll();
	
	void searchSerial(String serial);
	
	void searchTitle(String title);
	
	void searchTv();
	
	void searchRef();
	
	void searchVolumeRef();
	
	void searchSizeTv();
	
	void changeInfo();
	
	void removeItem();
	
	void priceAll();
}
