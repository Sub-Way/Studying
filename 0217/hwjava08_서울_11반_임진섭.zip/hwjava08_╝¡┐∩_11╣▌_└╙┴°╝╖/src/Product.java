
public class Product {
	protected String serial = "";
	protected String title = "";
	protected int price = 0;
	protected int quantity = 0;
	
	public Product(String serial, String title, int price, int quantity) {
		this.serial = serial;
		this.title = title;
		this.price = price;
		this.quantity= quantity;
	}
	
	
	public Product(String serial, String title, int price, int quantity, int inch, String type) {
		this.serial = serial;
		this.title = title;
		this.price = price;
		this.quantity= quantity;
	}


	public Product(String serial, String title, int price, int quantity, int volume) {
		this.serial = serial;
		this.title = title;
		this.price = price;
		this.quantity= quantity;
	}


	public String getSerial() {
		return serial;
	}
	public void setSerial(String serial) {
		this.serial = serial;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String toString() {
		String str = serial + "	| " + title + "	| " + price + "	| " + quantity;
		return str;
	}
}
