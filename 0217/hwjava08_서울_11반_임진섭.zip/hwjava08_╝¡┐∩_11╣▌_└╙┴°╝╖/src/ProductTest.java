
public class ProductTest {
	public static void main(String[] args) {
		
		/**
		 * 각각의 메소드에 해당하는 input값을 사용자가 직접 입력해야 함.
		 */
		TV tv = new TV("1234", "삼성", 1000, 1, 100, "LED");
		Refigerator ref = new Refigerator("1111", "LG", 500, 2, 450);
		
		ProductMgrImpl Impl = new ProductMgrImpl();
		System.out.println("TV 정보 입력");
		Impl.inputTv(tv);
		System.out.println("냉장고 정보 입력");
		Impl.inputRef(ref);
		System.out.println("모든 정보 출력");
		Impl.searchAll();
		System.out.println("시리얼 번호 검색");
		Impl.searchSerial("1234");
		System.out.println("타이틀 검색");
		Impl.searchTitle("LG");
		System.out.println("TV 검색");
		Impl.searchTv();
		System.out.println("냉장고 검색");
		Impl.searchRef();
		System.out.println("L 검색");
		Impl.searchVolumeRef();
		System.out.println("사이즈 검색");
		Impl.searchSizeTv();
		System.out.println("상품 정보 변경");
		Impl.changeInfo();
		System.out.println("모든 정보 출력");
		Impl.searchAll();
		System.out.println("상품 정보 삭제");
		Impl.removeItem();
		System.out.println("모든 정보 출력");
		Impl.searchAll();
		System.out.println("모든 가격 검색");
		Impl.priceAll();
	}
}
