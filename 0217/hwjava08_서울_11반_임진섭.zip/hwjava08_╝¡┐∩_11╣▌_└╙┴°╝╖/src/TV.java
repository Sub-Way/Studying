
public class TV extends Product {

	protected int inch = 0;
	protected String type = "";

	public TV(String serial, String title, int price, int quantity, int inch, String type) {
		super(serial, title, price, quantity);
		this.serial=serial;
		this.title=title;
		this.price=price;
		this.quantity = quantity;
		this.inch = inch;
		this.type = type;
	}

	public void setInch(int inch) {
		this.inch = inch;
	}

	public int getInch() {
		return inch;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public String toString() {
		String str = serial + "	| " + title + "	| " + price + "	| " + quantity + "	| " +inch + "	| "+ type;
		return str;
	}
}
