
public class Refigerator extends Product{

	protected int volume = 0;
	
	public Refigerator(String serial, String title, int price, int quantity, int volume) {
		super(serial, title, price, quantity);
		this.serial=serial;
		this.title=title;
		this.price=price;
		this.quantity = quantity;
		this.volume = volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}
	
	public int getVolume() {
		return volume;
	}	

	public String toString() {
		String str = serial + "	| " + title + "	| " + price + "	| " + quantity + "	| " + volume;
		return str;
	}
}
