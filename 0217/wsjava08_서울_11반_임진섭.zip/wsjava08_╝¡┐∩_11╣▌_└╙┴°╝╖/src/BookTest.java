public class BookTest {
	public static void main(String[] args) {
		
		Book b = new Book("1234", "자바", "임진섭", "싸피", 1234, "좋아요");
		Magazine m = new Magazine("1111", "잡지", "홍길동", "역삼", 777, "재밌어요", 2020, 7);
		
		
		BookMgrlmpl lmpl = new BookMgrlmpl();
		lmpl.inputBook(b);
		System.out.println();
		lmpl.inputMagazine(m);
		System.out.println();
		lmpl.searchIsbn();
		lmpl.searchTitle();
		System.out.println("Book만 검색");
		lmpl.searchBook();
		System.out.println("Magazine만 검색");
		lmpl.searchMagazin();
		System.out.println("올해 Magazine만 검색");
		lmpl.MagazinThisYear();
		System.out.println("가격 검색");
		lmpl.searchPrice();
		System.out.println("모든 가격 검색");
		lmpl.priceAll();
		System.out.println("평균 가격 검색");
		lmpl.priceAverage();
	}
}
