import java.util.ArrayList;
import java.util.Scanner;

public class BookMgrlmpl implements IBookMgr {

	static Scanner sc = new Scanner(System.in);
	static ArrayList<Book> book = new ArrayList<Book>();
	
	@Override
	public void inputBook(Book b) {
		book.add(b);
	}

	@Override
	public void inputMagazine(Magazine m) {
		book.add(m);
	}
	
	@Override
	public void searchAll() {
		System.out.println("데이터 전체 검색");
		for (int i = 0; i < book.size(); i++) {
			System.out.println(book.get(i).toString());
		}	
	}


	@Override
	public void searchIsbn() {
		System.out.print("검색할 Isbn 입력 : ");
		String isbn = sc.next();
		for (int i = 0; i < book.size(); i++) {
			if (book.get(i).getIsbn().equals(isbn))
				System.out.println(book.get(i).toString());
		}
	}

	@Override
	public void searchTitle() {
		System.out.print("검색할 Title 입력 : ");
		String title = sc.next();
		for (int i = 0; i <  book.size(); i++) {
			if (book.get(i).getTitle().equals(title))
				System.out.println(book.get(i).toString());
		}
	}

	@Override
	public void searchBook() {
		for (int i = 0; i < book.size(); i++) {
			if (!(book.get(i) instanceof Magazine)) {
				System.out.println(book.get(i).toString());
			}
		}
	}

	@Override
	public void searchMagazin() {
		Magazine m;
		for (int i = 0; i < book.size(); i++) {
			if ((book.get(i) instanceof Magazine)) {
				m=(Magazine)book.get(i);
					System.out.println(m.toString());
			}
		}	
	}

	@Override
	public void MagazinThisYear() {
		Magazine m;
		for (int i = 0; i < book.size(); i++) {
			if ((book.get(i) instanceof Magazine)) {
				m=(Magazine)book.get(i);
				if(m.getYear() == 2020)
					System.out.println(m.toString());
			}
		}	
	}
	
	@Override
	public void searchPublisher() {
		System.out.print("검색할 Publisher 입력 : ");
		String publisher = sc.next();
		for (int i = 0; i < book.size(); i++) {
			if (book.get(i).getPublisher().equals(publisher))
				System.out.println(book.get(i).toString());
		}
	}
	
	@Override
	public void searchPrice() {
		System.out.print("검색할 가격 입력 : ");
		int price = sc.nextInt();
		for (int i = 0; i < book.size(); i++) {
			if (price > book.get(i).getPrice())
				System.out.println(book.get(i).toString());
		}
	}


	@Override
	public void priceAll() {
		int sum = 0;
		for (int i = 0; i < book.size(); i++) {
			sum += book.get(i).getPrice();
		}
		System.out.println(sum);
	}

	@Override
	public void priceAverage() {
		int sum = 0;
		for (int i = 0; i < book.size(); i++) {
			sum += book.get(i).getPrice();
		}
		int avg = sum / book.size();
		System.out.println(avg);
	}

}
