
public interface IBookMgr {
	public void inputBook(Book b);

	public void inputMagazine(Magazine m);

	public void searchAll();

	public void searchIsbn();

	public void searchTitle();

	public void searchBook();

	public void searchMagazin();

	public void searchPublisher();

	public void MagazinThisYear();

	public void searchPrice();
	
	public void priceAll();

	public void priceAverage();
}
