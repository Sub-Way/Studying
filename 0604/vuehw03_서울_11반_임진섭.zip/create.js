import test from './create_module.js';

    new Vue({
      el: '#app',
      // 폼 화면 입력값과 연관된 데이터 선언하기
      data: function () {
        return {
          no: '',
          name: '',
          department: '',
          position: '',
          salary: ''
        }
      },
      methods: {
        check(){
            test.checkHandler(this.position,this.name,this.salary,this.department);
        },
      }
});