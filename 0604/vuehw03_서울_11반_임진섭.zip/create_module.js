export default {
    checkHandler(position,name,salary,department) {
        // 사용자 입력값 체크하기
        // 작성자, 제목, 내용 
        // 없을 경우 각 항목에 맞는 메세지를 출력
        let err = true;
        let msg = '';
        !name && (msg = '사원명을 입력해주세요', err = false, $refs.name.focus());
        err && !department && (msg = '부서를 입력해주세요', err = false, $refs.department.focus());
        err && !position && (msg = '직책을 입력해주세요', err = false, $refs.position.focus());
        err && !salary && (msg = '연봉을 입력해주세요', err = false, $refs.salary.focus());

        if (!err) alert(msg);
        // 만약, 내용이 다 입력되어 있다면 createHandler 호출
        else this.createHandler(position,name,salary,department);
      },

      createHandler(position,name,salary,department) {
        // 로컬스토리지에 저장된 데이터 가져오기
        const board = localStorage.getItem('board');
        // 데이터 선언
        let newBoard = {
          sequence: 0,
          items: []
        };

        // 기존 로컬스토리지에 저장된 내용이 있다면 newBoard 객체를 변경
        if (board) {
          newBoard = JSON.parse(board);
        }

        // 글번호 증가
        newBoard.sequence += 1;
        // 화면 입력된 데이터를 newBoard에 추가
        newBoard.items.push({
          name: name,
          department: department,
          no: newBoard.sequence,
          position: position,
          salary: salary
        })
        // 로컬스트리지 저장
        localStorage.setItem('board', JSON.stringify(newBoard));
        // 등록 성공 메세지 출력
        alert('등록이 완료되었습니다.');
        // 목록 페이지로 이동하기
        location.href = './list.html';
      },
    };