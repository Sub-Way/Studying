
public class ProductTest {
	public static void main(String[] args) {
		ProductMgr pm = new ProductMgr();
		while(true) {
			pm.menu();
		}
	}
}
