import java.util.Scanner;

public class ProductMgr {
	int count = -1;
	Product[] pr = new Product[10];
	int index = -1;
	boolean[] remove = new boolean[10];
	int point = 0;
	static Scanner sc = new Scanner(System.in);

	public void menu() {
		System.out.println("	1.데이터 입력");
		System.out.println("	2.데이터 전체 검색");
		System.out.println("	3.상품번호로 검색");
		System.out.println("	4.상품명으로 검색");
		System.out.println("	5.TV정보만 검색");
		System.out.println("	6.Refigerator만 검색");
		System.out.println("	7.상품번호로 상품 삭제");
		System.out.println("	8.전체 재고 상품 금액 검색");
		System.out.print("	원하는 메뉴를 입력하세요 : ");
		int n = sc.nextInt();
		if (n == 1)
			Input();
		else if (n == 2)
			AllInfo();
		else if (n == 3)
			SerialInfo();
		else if (n == 4)
			TitleInfo();
		else if (n == 5)
			TvInfo();
		else if (n == 6)
			RefigeratorInfo();
		else if (n == 7)
			RemoveItem();
		else if (n == 8)
			TotalPrice();
	}

	public void Input() {
		count++;
		System.out.println("TV : 1, Refigerator : 2");
		int i = sc.nextInt();
		if (i == 1) {
			TV tv = new TV();
			pr[count] = tv;
			System.out.print("Serial 입력 : ");
			String serial = sc.next();
			tv.setSerial(serial);
			System.out.print("title 입력 : ");
			String title = sc.next();
			tv.setTitle(title);
			System.out.print("Price 입력 : ");
			int price = sc.nextInt();
			tv.setPrice(price);
			System.out.print("Quantity 입력 : ");
			int quantity = sc.nextInt();
			tv.setQuantity(quantity);
			System.out.print("Inch 입력 : ");
			int inch = sc.nextInt();
			tv.setInch(inch);
			System.out.print("Type 입력 : ");
			String type = sc.next();
			tv.setType(type);
			pr[count] = tv;

		} else if (i == 2) {
			Refigerator r = new Refigerator();
			pr[count] = r;
			System.out.print("Serial 입력 : ");
			String serial = sc.next();
			r.setSerial(serial);
			System.out.print("title 입력 : ");
			String title = sc.next();
			r.setTitle(title);
			System.out.print("Price 입력 : ");
			int price = sc.nextInt();
			r.setPrice(price);
			System.out.print("Quantity 입력 : ");
			int quantity = sc.nextInt();
			r.setQuantity(quantity);
			System.out.print("Volume 입력 : ");
			String volume = sc.next();
			r.setVolume(volume);
			pr[count] = r;
		}
	}

	public void AllInfo() {
		for (int i = 0; i < count + 1; i++) {
			if (remove[i] == false)
				System.out.println(pr[i].toString());
		}
	}

	public void SerialInfo() {
		System.out.print("검색할 Serial 입력 : ");
		String serial = sc.next();
		for (int i = 0; i < count + 1; i++) {
			if (pr[i].getSerial().equals(serial)) {
				if (remove[i] == false)
					System.out.println(pr[i].toString());
			}
		}
	}

	public void TitleInfo() {
		System.out.print("검색할 Title 입력 : ");
		String title = sc.next();
		for (int i = 0; i < count + 1; i++) {
			if (pr[i].getTitle().contains(title)) {
				if (remove[i] == false)
					System.out.println(pr[i].toString());
			}
		}
	}

	public void TvInfo() {
		for (int i = 0; i < count + 1; i++) {
			if (!(pr[i] instanceof Refigerator)) {
				if (remove[i] == false)
					System.out.println(pr[i].toString());
			}
		}
	}

	public void RefigeratorInfo() {
		for (int i = 0; i < count + 1; i++) {
			if (!(pr[i] instanceof TV)) {
				if (remove[i] == false)
					System.out.println(pr[i].toString());
			}
		}
	}

	public void RemoveItem() {
		System.out.print("삭제할 Serial 입력 : ");
		String serial = sc.next();
		for (int i = 0; i < count + 1; i++) {
			if (pr[i].getSerial().equals(serial))
				remove[i] = true;
		}
		System.out.println("성공적으로 삭제되었습니다.");
	}

	public void TotalPrice() {
		int sum = 0;
		for (int i = 0; i < count + 1; i++) {
			if (remove[i]==false)
				sum = sum + (pr[i].getPrice() * pr[i].getQuantity());
		}
		System.out.println("전체 재고 상품 금액 : " + sum);
	}
}