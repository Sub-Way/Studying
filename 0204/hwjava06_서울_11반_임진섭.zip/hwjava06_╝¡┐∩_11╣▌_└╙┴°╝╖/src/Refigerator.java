
public class Refigerator extends Product{
	protected String volume = "";
	
	public void setVolume(String volume) {
		this.volume = volume;
	}
	
	public String getVolume() {
		return volume;
	}	

	public String toString() {
		String str = serial + "	| " + title + "	| " + price + "	| " + quantity + "	| " + volume;
		return str;
	}
}
