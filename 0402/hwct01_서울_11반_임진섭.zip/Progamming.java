import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Progamming {
	static int[] arr;
	static int n, k;
	static double max;
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int t = Integer.parseInt(br.readLine()); // 테스트 케이스 개수
		
		for (int tc = 1; tc <= t; tc++) {
			StringTokenizer st = new StringTokenizer(br.readLine(), " ");
			n = Integer.parseInt(st.nextToken()); // 볼 수 있는 총 강좌 수
			k = Integer.parseInt(st.nextToken()); // 선택할 강좌의 수
			
			arr = new int[n]; // 강의를 저장할 배열
			max = Double.MIN_VALUE;
			st = new StringTokenizer(br.readLine());
			for (int i = 0; i < n; i++) {
				arr[i] = Integer.parseInt(st.nextToken());
			}
			
			Arrays.sort(arr);
			cur(arr);
			System.out.println("#" + tc + " " + max);
			
		} // end of tc
		
	} // end of main
	private static void cur(int[] temp) {
		Arrays.sort(temp);
		int len = 1;
		double result = 0;
		for (int i = temp.length-1; i >= temp.length-k; i--) {
			result += temp[i]/Math.pow(2, len++);
		}
		max = Math.max(max, result);
	}
} // end of class
