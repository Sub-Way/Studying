import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Poker {
	static String[] srr;
	static int[] rank;
	static int[] suit;
	static int[] suitcnt;
	static int[] rankcnt;
	static boolean flag;

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int t = Integer.parseInt(br.readLine()); // 테스트 케이스 개수

		for (int tc = 1; tc <= t; tc++) {
			StringTokenizer st = new StringTokenizer(br.readLine(), " ");
			srr = new String[5];
			rank = new int[13];
			suit = new int[4];
			suitcnt = new int[5];
			rankcnt = new int[5];
			flag = false;
			for (int i = 0; i < 5; i++) {
				srr[i] = st.nextToken();
			}

			for (int i = 0; i < 5; i++) {
				switch (srr[i].charAt(0)) {
				case 'S':
					suit[0]++;
					break;
				case 'D':
					suit[1]++;
					break;
				case 'H':
					suit[2]++;
					break;
				case 'C':
					suit[3]++;
					break;
				} // end of suit search

				if (srr[i].charAt(1) - '0' < 10) {
					rank[(srr[i].charAt(1) - '0')-1]++;
				} else {
					switch (srr[i].charAt(1)) {
					case 'A':
						rank[0]++;
						break;
					case 'T':
						rank[9]++;
						break;
					case 'J':
						rank[10]++;
						break;
					case 'Q':
						rank[11]++;
						break;
					case 'K':
						rank[12]++;
						break;
					}
				} // end of rank search
			} // end of main

			System.out.print("#" + tc + " ");
			check();

		} // end of tc
	} // end of main

	private static void check() {
		for (int i = 0; i < suit.length; i++) {
			if (suit[i] != 0) {
				suitcnt[suit[i] - 1]++;
			}
		} // end of suitcnt check

		for (int i = 0; i < rank.length; i++) {
			if (rank[i] != 0) {
				rankcnt[rank[i] - 1]++;
			}
		} // end of rankcnt check

		
		
		if (suitcnt[4] == 1) { // 모두 동일한 슈트일 때 1,4번 구분
			int count = 0;
			for (int i = 0; i < rank.length - 1; i++) {
				if (rank[i] == 1 && rank[i + 1] == 1) {
					count++;
				}
				if(count == 4)
					break;
			}
			if (count == 4) {
				System.out.println("Straight Flush");
				return;
			} else {
				System.out.println("Flush");
				return;
			}
		}

		else if (suitcnt[4] != 1) {
			int count = 0;
			for (int i = 0; i < rank.length - 1; i++) {
				if (rank[i] == 1 && rank[i + 1] == 1) {
					count++;
				}
			}
			if(count == 4) {
				System.out.println("Straight");
				return;
			}
			else if (rankcnt[3] == 1) { // 4개의 랭크가 같음 - 2번
				System.out.println("Four of a Kind");
				return;
			}
			else if (rankcnt[2] == 1 && rankcnt[1] == 1) { // -3번
				System.out.println("Full House");
				return;
			} else if (rankcnt[2] == 1) { // 동일한 랭크가 3장 - 6번
				System.out.println("Three of a kind");
				return;
			} else if (rankcnt[1] == 2) { // 동일한 랭크가 2장씩 두개 - 7번
				System.out.println("Two pair");
				return;
			} else if (rankcnt[1] == 1) { // 동일한 랭크가 2장 - 8번
				System.out.println("One pair");
				return;
			} else { // - 9번
				System.out.println("High card");
				return;
			}
		}
		
		
		
	} // end of check

} // end of class
