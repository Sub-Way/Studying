import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class hwalgo0416_서울_11반_임진섭{
	static int max = Integer.MIN_VALUE;
	static int[] arr;
	static int[][] memo;
	static int n;

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		arr = new int[n + 1];
		memo = new int[n + 1][2];

		for (int i = 1; i < arr.length; i++) {
			arr[i] = Integer.parseInt(br.readLine());
		}
		
		memo[1][0] = memo[1][1] = arr[1];
		
		for (int i = 2; i <= n; i++) {
			memo[i][1] = Math.max(memo[i-2][1], memo[i-2][0]) +arr[i];
			memo[i][0] = memo[i-1][1] + arr[i];
		}
		System.out.println(Math.max(memo[n][0], memo[n][1]));
		
	} // end of main
} // end of class