package Service;

import java.sql.SQLException;
import java.util.List;

import Dto.ProductDto;

public interface ProductService {

	public void writeArticle(ProductDto productDto) throws SQLException;
	public List<ProductDto> listArticle() throws SQLException;
}