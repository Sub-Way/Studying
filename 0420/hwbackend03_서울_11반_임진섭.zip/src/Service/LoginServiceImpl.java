package Service;

import Dto.MemberDto;
import Dao.LoginDao;
import Dao.LoginDaoImpl;

public class LoginServiceImpl implements LoginService {

	LoginDao loginDao;
	
	public LoginServiceImpl() {
		loginDao = new LoginDaoImpl();
	}
	
	@Override
	public MemberDto login(String userid, String userpwd) throws Exception {
		if(userid == null || userpwd == null)
			throw new Exception(); // DB가 일 할 필요가 없다.
		return loginDao.login(userid, userpwd);
	}

}
