package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.ProductDaoImpl;
import Dto.MemberDto;
import Dto.ProductDto;
import Service.LoginService;
import Service.LoginServiceImpl;
import Service.ProductService;


@WebServlet("/main.do")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private LoginService loginService;
	private ProductService productService;

	public void init() {
		loginService = new LoginServiceImpl();
		//ProductService = new 
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			process(request,response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		try {
			process(request,response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("2");
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		String root = request.getContextPath(); // /guestbookmvc
		System.out.println(root);
		String path = "/index.jsp";
		System.out.println("request : " + request);
		System.out.println("1");
		
		String act = request.getParameter("act");
		System.out.println("act : " + act);
		
		if("login".equals(act)) {
			login(request,response);
		}else if("insert".equals(act)) {
			insert(request,response);
			System.out.println(act);
		}
	}
	
	private void insert(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException, SQLException {
		request.setCharacterEncoding("utf-8"); //POST
		String name = request.getParameter("name");
		System.out.println(name);
		String price = request.getParameter("price");
		System.out.println(price);
		String desc = request.getParameter("desc");
		System.out.println(desc);
		
		ProductDto dto = new ProductDto(name,price,desc);
		ProductDaoImpl pdi = new ProductDaoImpl();
		pdi.writeArticle(dto);
	}

	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");
		Cookie c = new Cookie("last", userid);
		response.addCookie(c);
		System.out.println(c.getName() + " " + c.getValue());

		try {
			MemberDto memberDto = loginService.login(userid, userpwd); // null인지 null이 아닌지에 따라서 로그인의 여부가 결정
			if(memberDto != null) { // 로그인 성공
				///////////////////// session //////////////////////
				HttpSession session = request.getSession();
				session.setAttribute("userinfo", memberDto);
				//request.setAttribute("userinfo", memberDto);
				////////////////////////////////////////////////////
//				path = "/index.jsp";
			}else { // 실패
				request.setAttribute("msg", "아이디 또는 비밀번호를 확인해 주세요.");
//				path = "/index.jsp";				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.getRequestDispatcher(path).forward(request, response); // forward 방식
	}
	
}
