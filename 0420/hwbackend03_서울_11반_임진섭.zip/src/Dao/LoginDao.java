package Dao;

import java.sql.SQLException;

import Dto.MemberDto;

public interface LoginDao {

	public MemberDto login(String userid, String userpwd) throws SQLException;
	
}
