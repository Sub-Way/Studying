package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Dto.ProductDto;
import DB.DBUtil;;

public class ProductDaoImpl implements ProductDao {

	@Override
	public void writeArticle(ProductDto productDto) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("insert into product (`name`, `price`, `desc`) \n");
			insertMember.append("values (?, ?, ?)");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, productDto.getName());
			System.out.println(productDto.getName());
			pstmt.setString(2, productDto.getPrice());
			System.out.println(productDto.getPrice());
			pstmt.setString(3, productDto.getDesc());
			System.out.println(productDto.getDesc());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

	@Override
	public List<ProductDto> listArticle() throws SQLException {
		List<ProductDto> list = new ArrayList<ProductDto>();
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select articleno, name, price, desc \n");
			sql.append("from product \n");
//			검색
			sql.append("order by articleno desc \n");
			pstmt = conn.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
			while(rs.next()) {
				ProductDto productDto = new ProductDto();
				productDto.setArticleno(rs.getInt("articleno"));
				productDto.setName(rs.getString("name"));
				productDto.setPrice(rs.getString("price"));
				productDto.setDesc(rs.getString("desc"));
				
				list.add(productDto);
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return list;
	}

//	@Override
//	public ProductDto getArticle(int articleno) throws SQLException {
//		ProductDto productDto = null;
//		
//		Connection conn = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		
//		try {
//			conn = DBUtil.getConnection();
//			StringBuilder sql = new StringBuilder();
//			sql.append("select articleno, name, price, desc \n");
//			sql.append("from product \n");
//			sql.append("where articleno = ?");
//			pstmt = conn.prepareStatement(sql.toString());
//			pstmt.setInt(1, articleno);
//			rs = pstmt.executeQuery();
//			if(rs.next()) {
//				productDto = new ProductDto();
//				productDto.setArticleno(rs.getInt("articleno"));
//				productDto.setName(rs.getString("name"));
//				productDto.setPrice(rs.getString("price"));
//				productDto.setDesc(rs.getString("desc"));
//			}
//		} finally {
//			DBUtil.close(rs);
//			DBUtil.close(pstmt);
//			DBUtil.close(conn);
//		}
//		return productDto;
//	}

}
