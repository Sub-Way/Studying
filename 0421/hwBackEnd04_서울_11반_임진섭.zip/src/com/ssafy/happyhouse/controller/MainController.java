package com.ssafy.happyhouse.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;
import com.ssafy.happyhouse.model.dto.FindDto;
import com.ssafy.happyhouse.model.dto.ProductDto;
import com.ssafy.happyhouse.model.service.FindService;
import com.ssafy.happyhouse.model.service.FindServiceImpl;
import com.ssafy.happyhouse.model.service.ProductService;
import com.ssafy.happyhouse.model.service.ProductServiceImpl;

/**
 * Servlet implementation class UserController
 */
@WebServlet("/main.do")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ProductService productservice;
	private FindService findservice;

	@Override
	public void init() throws ServletException {
		super.init();
		productservice = new ProductServiceImpl();
		findservice = new FindServiceImpl();
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			process(request,response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		try {
			process(request,response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		String root = request.getContextPath(); // /guestbookmvc
		String path = "/index.jsp";
		
		String act = request.getParameter("act");
		
		if("mvjoin".equals(act)) {
			path = "/user/join.jsp"; // 유지보수가 좋은 부분
			redirect(response, path, root);
		}else if("mvwrite".equals(act)) {
			path = "/guestbook/write.jsp"; // 유지보수가 좋은 부분
			redirect(response, path, root);
		}else if("delete".equals(act)) {
			delete(request,response);
		}else if("input".equals(act)) {
			System.out.println("넘어왔지롱");
			input(request,response);
		}else if("list".equals(act)) {
			listArticle(request, response);
		}else if("word".equals(act)) {
			findInfo(request, response);
		}
	}


	private void findInfo(HttpServletRequest request, HttpServletResponse response) {
		String path = "/index.jsp";
		String name = request.getParameter("word");
		System.out.println("찾자>>>>>>>>>>>>" + name);
		
		try {
			List<ProductDto> list = findservice.getInfo(name);
			for (int i = 0; i < list.size(); i++) {
				System.out.println(list.get(i).getNo() + " " + list.get(i).getName() + " " + list.get(i).getPrice() + " " + list.get(i).getComm());
			}
			path = "/user/findsuccess.jsp";
			request.setAttribute("info", list);
			System.out.println(list);
			forward(request, response, path);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "비밀번호 찾기 중 문제가 발생했습니다.");
			path = "/error/error.jsp";
		}
		
	}

	private void input(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String path = "/user/info.jsp";
		String root = request.getContextPath();
		
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String comm = request.getParameter("comm");
		
		ProductDto productdto = new ProductDto();
		productdto.setName(name);
		productdto.setPrice(price);
		productdto.setComm(comm);
		try {
			productservice.input(productdto);
			HttpSession session = request.getSession();
			session.setAttribute("product", productdto);
			redirect(response, path, root);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) {
		String root = request.getContextPath();
		String path = "/index.jsp";
		String no = request.getParameter("info");
		System.out.println(no);
		
		System.out.println("삭제실행이지롱");
		
		try {
			productservice.delete(no);
			path = "/user/deletesuccess.jsp";
			ProductServiceImpl pdi = new ProductServiceImpl();
			List<ProductDto> list = null;
			list = pdi.listArticle();
			request.setAttribute("info", list);
			forward(request, response, path);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "글삭제 처리 중 문제가 발생했습니다.");
			path = "/error/error.jsp";
			//request.getRequestDispatcher(path).forward(request, response);
		}
	}


	private void listArticle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		String path = "/user/list.jsp";
		ProductServiceImpl pdi = new ProductServiceImpl();
		List<ProductDto> list = null;
		list = pdi.listArticle();
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getNo() + " " + list.get(i).getName() + " " + list.get(i).getPrice() + " " + list.get(i).getComm());
		}
		request.setAttribute("info", list);
		forward(request, response, path);
	}
	
	private void forward(HttpServletRequest request, HttpServletResponse response, String path)
			throws ServletException, IOException {
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void redirect(HttpServletResponse response, String path, String root) throws IOException {
		response.sendRedirect(root + path);
	}
}