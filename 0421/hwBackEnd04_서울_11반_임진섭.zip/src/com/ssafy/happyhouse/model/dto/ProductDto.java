package com.ssafy.happyhouse.model.dto;

public class ProductDto {
	private int no;
	private String name;
	private String price;
	private String comm;
	
	public ProductDto() {};
	
	public ProductDto(String name, String price, String comm) {
		super();
		this.name = name;
		this.price = price;
		this.comm = comm;
	}
	
	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}

	public String getComm() {
		return comm;
	}

	public void setComm(String comm) {
		this.comm = comm;
	}

}
