package com.ssafy.happyhouse.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.happyhouse.model.dto.FindDto;
import com.ssafy.happyhouse.model.dto.ProductDto;
import com.ssafy.happyhouse.util.DBUtil;

public class FindDaoImpl implements FindDao{

	@Override
	public List<ProductDto> getInfo(String name) throws SQLException {
		List<ProductDto> list = new ArrayList<ProductDto>();
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select no, name, price, comm \n");
			sql.append("from product \n");
			sql.append("where name like ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, "%"+name+"%");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ProductDto productdto = new ProductDto();
				productdto.setNo(rs.getInt("no"));
				productdto.setName(name);
				productdto.setPrice(rs.getString("price"));
				productdto.setComm(rs.getString("comm"));
				System.out.println("출력!!!!!!!!");
				list.add(productdto);
			}
		} finally {
			System.out.println(list.size());
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return list;
	}

}
