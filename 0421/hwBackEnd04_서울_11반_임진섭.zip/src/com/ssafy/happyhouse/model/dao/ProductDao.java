package com.ssafy.happyhouse.model.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.model.dto.ProductDto;

public interface ProductDao {

	public void input(ProductDto productDto);
	public List<ProductDto> listArticle() throws SQLException;
	public ProductDto getArticle(String name) throws SQLException;
	public void delete(String no) throws SQLException;
}
