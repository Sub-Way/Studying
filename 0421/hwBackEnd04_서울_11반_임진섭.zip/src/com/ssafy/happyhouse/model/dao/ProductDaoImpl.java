package com.ssafy.happyhouse.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.happyhouse.model.dto.ProductDto;
import com.ssafy.happyhouse.util.DBUtil;

public class ProductDaoImpl implements ProductDao {

	@Override
	public void input(ProductDto productDto) {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into product(name, price, comm) values (?, ?, ?)");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, productDto.getName());
			System.out.println(">>>>>>>>>>>>" + productDto.getName());
			pstmt.setString(2, productDto.getPrice());
			pstmt.setString(3, productDto.getComm());
			int cnt = pstmt.executeUpdate();
			System.out.println("변경된 row : " + cnt);
		} catch (SQLException e) {
			System.out.println("SQL 에러");
			e.printStackTrace();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

	@Override
	public List<ProductDto> listArticle() throws SQLException {
		List<ProductDto> list = new ArrayList<ProductDto>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select no, name, price, comm \n");
			sql.append("from product \n");
			sql.append("order by no desc \n");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProductDto productdto = new ProductDto();
				productdto.setNo(rs.getInt("no"));
				productdto.setName(rs.getString("name"));
				productdto.setPrice(rs.getString("price"));
				productdto.setComm(rs.getString("comm"));

				list.add(productdto);
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}

		return list;
	}

	@Override
	public ProductDto getArticle(String name) throws SQLException {
		ProductDto guestBookDto = null;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select no, name, price, comm \n");
			sql.append("from product \n");
			sql.append("where name = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				ProductDto productdto = new ProductDto();
				productdto.setNo(rs.getInt("no"));
				productdto.setName(rs.getString("name"));
				productdto.setPrice(rs.getString("price"));
				productdto.setComm(rs.getString("comm"));
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return guestBookDto;
	}

	@Override
	public void delete(String no) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("delete from product \n");
			insertMember.append("where no = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, no);
			System.out.println(no);
			pstmt.executeUpdate();
			System.out.println("삭제완료!");
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}
}
