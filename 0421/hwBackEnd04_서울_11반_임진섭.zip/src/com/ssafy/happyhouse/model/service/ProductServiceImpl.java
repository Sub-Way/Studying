package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.model.dao.ProductDao;
import com.ssafy.happyhouse.model.dao.ProductDaoImpl;
import com.ssafy.happyhouse.model.dto.ProductDto;

public class ProductServiceImpl implements ProductService{

	ProductDao productDao;
	
	public ProductServiceImpl() {
		productDao = new ProductDaoImpl();
	}
	
	@Override
	public void input(ProductDto productDto) throws Exception {
		if (productDto.getName() == null || productDto.getPrice() == null || productDto.getComm() == null) {
			throw new Exception();
		}
		System.out.println("input서비스실행");
		productDao.input(productDto);
	}


	@Override
	public ProductDto getArticle(String name) throws SQLException {
		return productDao.getArticle(name);
	}

	@Override
	public List<ProductDto> listArticle() throws SQLException {
		return productDao.listArticle();
	}

	@Override
	public void delete(String no) throws Exception {
		productDao.delete(no);
	}
}
