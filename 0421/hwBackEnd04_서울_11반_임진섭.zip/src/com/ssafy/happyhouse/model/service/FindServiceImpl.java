package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.model.dao.FindDao;
import com.ssafy.happyhouse.model.dao.FindDaoImpl;
import com.ssafy.happyhouse.model.dto.FindDto;
import com.ssafy.happyhouse.model.dto.ProductDto;

public class FindServiceImpl implements FindService{

private FindDao findDao;
	
	public FindServiceImpl() {
		findDao = new FindDaoImpl();
	}
	
	@Override
	public List<ProductDto> getInfo(String name) throws SQLException {
		// TODO Auto-generated method stub
		return findDao.getInfo(name);
	}
}
