package com.ssafy.happyhouse.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.happyhouse.model.dto.ProductDto;

public interface ProductService {
	
	public void input(ProductDto productDto) throws Exception;
	public List<ProductDto> listArticle() throws SQLException;
	public ProductDto getArticle(String name) throws Exception;
	public void delete(String no) throws Exception;
}
