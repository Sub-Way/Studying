create table user(
no          int primary key auto_increment,
name       varchar(20) NOT NULL,
price        varchar(20) NOT NULL,
comm       varchar(100) NOT NULL
);