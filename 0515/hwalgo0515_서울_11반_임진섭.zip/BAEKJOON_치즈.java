/*
 * @author LJS
 * 메모리 15828KB 시간 104ms
 * 풀이방법 : DFS
 * 어려웠던점 : 문제 접근 방법(바깥 영역 처리)
 * 해결법 : 외곽(0,0)을 기준으로 0또는-1일 때 공기부분을 처리함
 * 개선방안 : 문제를 빠르게 해결하기
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class BAEKJOON_치즈 {
	static int n, m;
	static int[][] arr;
	static boolean[][] check;
	static int dir[][] = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };
	static ArrayList<Dot> list;
	static ArrayList<Info> info = new ArrayList<>();
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");

		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());
		arr = new int[n][m];
		for (int i = 0; i < n; i++) {
			st = new StringTokenizer(br.readLine(), " ");
			for (int j = 0; j < m; j++) {
				arr[i][j] = Integer.parseInt(st.nextToken());
			}
		}

		int time = 0;
		while (true) {
			list = new ArrayList<>(); // 공기와 인접한 치즈의 좌표를 저장할 리스트
			check = new boolean[n][m];
			int cnt = 0;
			
			dfs(0, 0); // 바깥 영역 공기 -1로 바꿔주고 공기와 인접한 부분 리스트에 저장
			for (int i = 0; i < list.size(); i++) { // 다음에 녹을 치즈 값 2로 변경
				arr[list.get(i).y][list.get(i).x] = 2;
			}

			for (int i = 0; i < n; i++) {
				for (int j = 0; j < m; j++) {
					if(arr[i][j] == 2) // 남아있는 치즈 수
						cnt++; 
				}
			}
			
			if(cnt == 0) { // 치즈가 모두 사라지면 종료
				break;
			}
			
			else { // 치즈가 남아 있다면
				time++; // 횟수 증가
				info.add(new Info(time, cnt)); // 횟수와 남아있는 치즈 수 저장
			}
		}
			
		System.out.println(info.size());
		System.out.println(info.get(info.size()-1).cnt);
	} // end of main

	public static void dfs(int y, int x) {
		check[y][x] = true;
		arr[y][x] = -1;

		for (int m = 0; m < dir.length; m++) {
			int nx = x + dir[m][1];
			int ny = y + dir[m][0];

			if (isin(ny, nx) && !check[ny][nx] && (arr[ny][nx] == 0 || arr[ny][nx] == -1 || arr[ny][nx] == 2)) { // 공기부분이거나 다음에 녹을 치즈라면
				check[ny][nx] = true;
				arr[ny][nx] = -1; // -1로 갱신
				dfs(ny, nx); // 재귀 호출
			}

			else if (isin(ny, nx) && !check[ny][nx] && arr[ny][nx] == 1) { // 인접한 부분이 치즈라면
				check[ny][nx] = true;
				list.add(new Dot(ny, nx)); // 리스트에 좌표 값 저장
			}

		}
	}

	public static boolean isin(int ny, int nx) {
		return 0 <= ny && ny < n && 0 <= nx && nx < m;
	}

	static class Dot {
		int y;
		int x;

		public Dot(int y, int x) {
			this.y = y;
			this.x = x;
		}
	}

	static class Info {
		int time;
		int cnt;
		
		public Info(int time, int cnt) {
			this.time = time;
			this.cnt = cnt;
		}
	}
} // end of class
