package com.ssafy.product;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/product.do")
public class ProductTest extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. data get
		String productname = request.getParameter("productname");
		int productprice = Integer.parseInt(request.getParameter("productprice"));
		String productcomm = request.getParameter("productcomm");

		List<ProductDTO> list = new ArrayList<ProductDTO>();

		ProductDTO dto = new ProductDTO();
		dto.setProductname(productname);
		dto.setProductprice(productprice);
		dto.setProudctcomm(productcomm);
		list.add(dto);
		
		request.setAttribute("articles", list);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/product/list.jsp");
		dispatcher.forward(request, response);
	}
}
