package com.ssafy.product;

public class ProductDTO {
	private String productname;
	private int productprice;
	private String productcomm;
	
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public int getProductprice() {
		return productprice;
	}
	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}
	public String getProudctcomm() {
		return productcomm;
	}
	public void setProudctcomm(String proudctcomm) {
		this.productcomm = proudctcomm;
	}
	
}
