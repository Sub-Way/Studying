import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;

public class hw_algo0429_서울_11반_임진섭 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		
		int t = Integer.parseInt(br.readLine());
		
		for (int tc = 1; tc <= t; tc++) {
			int sum = 0;
			int n = Integer.parseInt(br.readLine());
			ArrayList<Integer> list = new ArrayList<Integer>();
			StringTokenizer st= new StringTokenizer(br.readLine(), " ");
			
			for (int i = 0; i < n; i++) {
				int num = Integer.parseInt(st.nextToken());
				list.add(num);
				sum+=num;
			} // end of input
			
			
			Collections.sort(list,Collections.reverseOrder());
			for (int i = 0; i < list.size(); i++) {
				if(i%3 == 2) {
					sum -= list.get(i);
				}
			}
			
			System.out.println("#" + tc + " " + sum);
			
		} // end of tc
		
		
	} // end of main
} // end of class
