package com.ssafy.board.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssafy.board.dto.Board;
import com.ssafy.board.service.BoardService;

@RequestMapping(value = "/guest")
@Controller
public class BoardControllerImpl implements BoardController {

	@Autowired
	BoardService service;
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	@Override
	public String moveForList() {
		return "board_list";
	}

	@RequestMapping(value = "/list2", method = RequestMethod.GET)
	@Override
	public String boardListNoPaging(Model model) {
		List<Board> list = service.boardListNoPaging();
		model.addAttribute("board_list", list);
		return "board_list";
	}

	@RequestMapping(value = "/writeform", method = RequestMethod.GET)
	@Override
	public String moveForWrite() {
		return "board_write_form";
	}

	@RequestMapping(value = "/write", method = RequestMethod.POST)
	@Override
	public String boardRegist(Board board) {
		int successCnt = service.boardRegist(board);
		
		return "redirect:/guest/list2";
	}

	@RequestMapping(value = "/detail", method = RequestMethod.GET)
	@Override
	public String boardDetail(String no, Model model) {
		Board board = service.boardDetail(no);
		model.addAttribute("board_dto", board);
		return "board_detail";
	}

	@RequestMapping(value = "/modifyform", method = RequestMethod.GET)
	@Override
	public String moveForModity(String no, Model model) {
		Board board = service.boardDetail(no);
		model.addAttribute("board_dto", board);
		return "board_update_form";
	}

	@RequestMapping(value = "/modify", method = RequestMethod.POST)
	@Override
	public String boardModify(Board board) {
		int successCnt = service.boardModify(board);
		
		return "redirect:/guest/list2";
	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	@Override
	public String boardDelete(String no) {
		int successCnt = service.boardDelete(no);
		return "redirect:/guest/list2";
	}

}
