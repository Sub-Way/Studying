package com.ssafy.board.dto;

public class Board {

	private String articleno;
	private String name;
	private String price;
	private String comm;
	
	public Board() {
		
	}

	public Board(String articleno, String name, String price, String comm) {
		super();
		this.articleno = articleno;
		this.name = name;
		this.price = price;
		this.comm = comm;
	}

	public String getArticleno() {
		return articleno;
	}

	public void setArticleno(String articleno) {
		this.articleno = articleno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getComm() {
		return comm;
	}

	public void setComm(String comm) {
		this.comm = comm;
	}
	
}
