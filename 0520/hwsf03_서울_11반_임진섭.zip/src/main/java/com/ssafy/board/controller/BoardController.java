package com.ssafy.board.controller;

import java.util.List;

import org.springframework.ui.Model;

import com.ssafy.board.dto.Board;

public interface BoardController {

	public String moveForList(); // 게시판 목록으로 화면 이동
	
	public String boardListNoPaging(Model model); // 페이징 없는 게시판 목록
	
	public String moveForWrite(); // 글 작성으로 화면 이동
	
	public String boardRegist(Board board); // 글 등록
	
	public String boardDetail(String no, Model model); // 글 상세
	
	public String moveForModity(String no, Model model); // 글 수정으로 화면 이동 (moveForWrite + boardDetail)
	
	public String boardModify(Board board); // 글 수정 (boardRegist)
	
	public String boardDelete(String articleno); // 글 삭제
	
//	public List<Board> boardListWithPaging(); // 페이징 있는 게시판 목록
	
//	파일업로드
}
