package com.ssafy.board.service;

import java.util.List;

import com.ssafy.board.dto.Board;

public interface BoardService {

	public int boardRegist(Board board); // 글 등록
	
	public List<Board> boardListNoPaging(); // 페이징 없는 게시판 목록
	
	public Board boardDetail(String no); // 글 상세
	
	public int boardDelete(String no); // 글 삭제
	
	public int boardModify(Board board); // 글 수정
}
