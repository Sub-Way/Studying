package com.ssafy.product.dto;

public class Product {
	private int no;
	private String name;
	private int price;
	private String comm;

	public Product() {
	}

	public Product(int no, String name, int price, String comm) {
		super();
		this.no = no;
		this.name = name;
		this.price = price;
		this.comm = comm;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getComm() {
		return comm;
	}

	public void setComm(String comm) {
		this.comm = comm;
	}

}
