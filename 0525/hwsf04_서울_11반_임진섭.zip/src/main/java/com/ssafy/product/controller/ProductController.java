package com.ssafy.product.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@Controller // 나 컨트롤러!! ---> servlet-context.xml등록
public class ProductController {

	@Autowired
	ProductService service;

	@RequestMapping("/test")
	public String test() {
		return "hello"; // JSP페이지 리턴
	}

	@RequestMapping("/test2")
	public @ResponseBody String test2() {
		return "hello"; // text(String) 데이터 리턴
	}

	@RequestMapping("/test3")
	public @ResponseBody String test3() {
//		if(service.modify()==1) return "success";
//		else return "fail";
		return "안녕, 싸피~!!"; // text(String) 데이터 리턴
	}

	@RequestMapping(value = "/form", method = RequestMethod.GET) // 입력폼보기
	public String form() {
		return "product/inputForm";
	}

	@RequestMapping(value = "/form", method = RequestMethod.POST) // DB입력
	public String formInsert(Product vo) {
		service.registry(vo);
		return "home";
	}

	@RequestMapping("/list")
	public String list(Model m) {
		m.addAttribute("list", service.findAll());// 뷰와 공유할 데이터를 영역에 저장
		return "product/list";// JSP페이지 포워딩
	}

	@RequestMapping(value = "/upform", method = RequestMethod.GET) // 수정폼 보이기
	public String upform(int no, Model m) {
		m.addAttribute("product", service.find(no));
		System.out.println("폼 가져오기");
		return "product/editForm";
	}

	@RequestMapping(value = "/upform", method = RequestMethod.POST) // DB수정하기
	public String update(Product vo) {
		System.out.println(vo.getNo());
		System.out.println(vo.getName());
		System.out.println(vo.getPrice());
		System.out.println(vo.getComm());
		service.modify(vo);
		System.out.println("수정성공");
		return "home";
	}

	@RequestMapping("/delete") // DB삭제하기
	public String delete(int no) {
		service.remove(no);
		return "home";
	}

	/*
	 * 컨트롤러내의 메소드 : MVC패턴 Servlet클래스의 service,doGet,doPost메소드역할 <컨트롤러의 역할> 1. 요청분석
	 * 2. 사용자 입력데이터 얻어오기 3. 서비스객체생성,호출 4. 데이터 영역저장(뷰와 공유) 5. 이동페이지
	 * 설정(forward,redirect)
	 */

	@RequestMapping("/m1") // 단순페이지 포워딩 (http://localhost:8080/product/m1 요청시)
							// 가상경로
	public String m1() {
		return "product/m1";
	}
	// prefix==> "/WEB-INF/views/"+"product/m1" + //suffix==> ".jsp"
	// "/WEB-INF/views/product/m1.jsp"

	@RequestMapping("/m2") // 단순페이지 포워딩 (http://localhost:8080/product/m2 요청시)
	public void m2() {
	}
	// 만약 요청URL과 결과JSP경로가 일치한다면 return 생략가능
	// "/WEB-INF/views/m2.jsp"

	@RequestMapping("/m3") // 리다이렉트 준비
	public String m3() {
		return "product/m3";
	}// "/WEB-INF/views/product/m3.jsp"

	@RequestMapping("/m4") // 리다이렉트 이동
	public String m4() {
		return "redirect:/m3";
	}

	@RequestMapping("/m5")
	public String m5(String name) {
		/*
		 * http://localhost:8080/product/m5?name=gildong
		 * 
		 * 또는
		 * 
		 * <form action="/product/m5" method=post> <input type=text name=name><br> <input
		 * type=submit value=전송> </form>
		 */
		System.out.println(name); // gildong출력
		return "product/m5";
	}

	@RequestMapping("/m6")
	public String m6(String name, int age) {
		/*
		 * http://localhost:8080/product/m6?name=gildong&age=13
		 * 
		 * 또는
		 * 
		 * <form action="/product/m6" method=post> <input type=text name=name><br> <input
		 * type=text name=age><br> <input type=submit value=전송> </form>
		 */
		System.out.println(name); // gildong출력
		System.out.println(age); // 13출력
		return "product/m6";
	}

	@RequestMapping("/m7")
	public String m7(Product p) {
		/*
		 * http://localhost:8080/product/m7?name=gildong&age=13
		 * 
		 * 또는
		 * 
		 * <form action="/product/m7" method=post> <input type=text name=name><br> <input
		 * type=text name=age><br> <input type=submit value=전송> </form>
		 * 
		 * 스프링프레임워크에서는 product p = new product(); p.setName(request.getParameter("name"));
		 * p.setAge(Integer.parseInt(request.getParameter("age"))); 코드생성
		 */
		System.out.println(p.getName()); // gildong출력
		System.out.println(p.getPrice()); // 13출력
		return "product/m7";
	}

	@RequestMapping("/m8")
	public String m8(int no, HttpServletRequest request) {

		request.setAttribute("product", service.find(no));

		return "product/m8";
	}

	@RequestMapping("/m8_2")
	public String m8(int no, Model model) {

		model.addAttribute("product", service.find(no));

		return "product/m8";
	}

	@RequestMapping("/m9")
	public String m9() {
		return "product/m9";
	}

	@RequestMapping("/m10")
	public String m10(int no, HttpSession session) {

		session.setAttribute("product", service.find(no));

		return "redirect:/m9";
	}

}
