package com.ssafy.product.repo;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.product.dto.Product;

@Repository
public class ProductDAOImpl implements ProductDAO{

	@Autowired
	SqlSession sqlSession;
	
	
	@Override
	public int insert(Product vo) {		
		return sqlSession.insert("product.insert",vo);
	}

	@Override
	public List<Product> selectAll() {
		return sqlSession.selectList("product.selectAll");
	}

	@Override
	public Product select(int no) {
		return sqlSession.selectOne("product.select",no);
	}

	@Override
	public int update(Product vo) {
		return sqlSession.update("product.update",vo);
	}

	@Override
	public int delete(int no) {
		return sqlSession.delete("product.delete",no);
	}

}
