package com.ssafy.product.service;

import java.util.List;

import com.ssafy.product.dto.Product;

public interface ProductService {
    public int registry(Product product);
    public int modify(Product product);
    public int remove(int no);
    public Product find(int no);
    public List<Product> findAll();
}


