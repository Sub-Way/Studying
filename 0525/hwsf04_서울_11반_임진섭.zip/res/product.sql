SELECT * FROM ssafyweb.product;

drop table product;

CREATE TABLE `product` (
  `articleno` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `comm` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`articleno`)
) ENGINE=InnoDB AUTO_INCREMENT=0;