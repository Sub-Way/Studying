package hwdb03_서울_11반_임진섭;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO implements DAO {
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("class loading failure");
		}
	}

	private Connection getConnection() throws SQLException {
		Connection con = DriverManager.getConnection(
				"jdbc:mysql://127.0.0.1:3305/scott?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8", "ssafy",
				"ssafy"); // url, id, pw
		return con;
	}

	public void insertProduct(String code, String name, int price) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = getConnection();
			String sql = "insert into product(code,name,price) values(?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, code);
			pstmt.setString(2, name);
			pstmt.setInt(3, price);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {if (pstmt != null)	pstmt.close();} catch (Exception e) {};
			try {if (conn != null)conn.close();} catch (Exception e) {}	;
		}
	}

	public void deleteProduct(String code) {
		PreparedStatement pstmt = null;
		Connection con = null;
		try {
			con = getConnection();
			String sql = "delete from product where code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void updateProduct(String code, int price) {
		PreparedStatement pstmt = null;
		Connection con = null;
		String sql = "update product set price = ? where code = ?";
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, price);
			pstmt.setString(2, code);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public List<Product> allViewCustomer() {
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		Connection conn = null;
		ArrayList<Product> list = new ArrayList<>();
		try {
			conn = getConnection();
			String sql = "select code, name, price from product";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				list.add(new Product(rs.getString("code"), rs.getString("name"), rs.getInt("price")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {if (rs != null) rs.close();} catch (Exception e) {};
			try {if (pstmt != null)	pstmt.close();} catch (Exception e) {};
			try {if (conn != null)conn.close();} catch (Exception e) {}	;
		}
		return list;
	}

	public Product findProduct(String code) {
		Product rtnProduct = new Product();
		String sql = "select code, name, price from product where code = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				rtnProduct.setCode(rs.getString("code"));
				rtnProduct.setName(rs.getString("name"));
				rtnProduct.setPrice(rs.getInt("price"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(con != null) con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return rtnProduct;
	}
}
