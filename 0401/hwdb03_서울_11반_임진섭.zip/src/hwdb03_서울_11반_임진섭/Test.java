package hwdb03_서울_11반_임진섭;

import java.util.List;

public class Test {
	public static void main(String[] args) {
		DAO dao = new ProductDAO();
		
		System.out.println("--------전체조회---------");
		List<Product> list = dao.allViewCustomer();
		for (Product product : list) {
			System.out.println(product);
		}
		
		System.out.println("--------상품정보 저장---------");
		dao.insertProduct("js12345", "세탁기", 1234500);
		list = dao.allViewCustomer();
		for (Product product : list) {
			System.out.println(product);
		}
		
		System.out.println("--------상품 삭제---------");
		dao.deleteProduct("js12345");
		list = dao.allViewCustomer();
		for (Product product : list) {
			System.out.println(product);
		}
		
		System.out.println("--------상세조회---------");
		System.out.println(dao.findProduct("js1234"));
		
		System.out.println("--------수정---------");
		dao.updateProduct("it3832",350000);
		list = dao.allViewCustomer();
		for (Product product : list) {
			System.out.println(product);
		}
	}
}