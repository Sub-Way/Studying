package hwdb03_서울_11반_임진섭;

import java.util.List;

public interface DAO {
	public void insertProduct(String code, String name, int price);
	public void updateProduct(String code, int price);
	public List<Product> allViewCustomer();
	public Product findProduct(String code);
	public void deleteProduct(String string);
}
