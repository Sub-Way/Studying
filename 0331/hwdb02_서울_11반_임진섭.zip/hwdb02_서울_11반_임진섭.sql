-- 1 상품정보를 저장할 수 있는 테이블을 구성하여 보자. (상품코드, 상품명, 상품가격 등)
create table product(code varchar(20), name varchar(20), price int);

-- 2. 상품 데이터를 5개 이상 저장하는 SQL을 작성하여 보자. ( 상품명에 TV, 노트북 포함 하도록 하여 5개 이상)
insert into product(code, name, price)
values('js1234', 'TV', 990000);

insert into product(code, name, price)
values('neyo0311', '노트북', 600000);

insert into product(code, name, price)
values('it3832', '세탁기', 1500000);

insert into product(code, name, price)
values('kane3831', '냉장고', 2300000);

insert into product(code, name, price)
values('son2821', '청소기', 450000);

insert into product(code, name, price)
values('js8421', 'TV', 1230000);

-- 3. 상품을 세일하려고 한다. 15% 인하된 가격의 상품 정보를 출력하세요.
select code as 상품코드, name as 상품명, price as 상품가격, round((price*0.85),0) as '15% 인하된 가격'
from product;

-- 4. TV 관련 상품을 가격을 20% 인하하여 저장하세요. 그 결과를 출력하세요.
select code as 상품코드, name as 상품명, price as 상품가격, round((price*0.80),0) as '20% 인하된 가격'
from product
where name = 'TV';

-- 5. 저장된 상품 가격의 총 금액을 출력하는 SQL 문장을 작성하세요.
select count(code) as '저장된 상품 수', sum(price) as '총 금액'
from product;