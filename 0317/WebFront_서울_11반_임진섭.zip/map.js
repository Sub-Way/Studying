/**
 * MyMap 생성자로 사용될 함수를 구현
 */
function MyMap(){
	this.elements = {};
	this.len = 0;
};   
MyMap.prototype.put = function(key, value){   
		this.len++;
		this.elements[key] = value;
}
MyMap.prototype.size = function(){
	var cnt = 0;
	for (var key in this.elements) {
		cnt++;
	}
	return cnt;
}
MyMap.prototype.get = function(key) {
  	 return this.elements[key];
}
MyMap.prototype.remove = function(key){
	delete this.elements[key];
}
MyMap.prototype.clear = function(){
	for (var key in this.elements) {
		delete this.elements[key];
	}
}