
public class ProductTest {
	public static void main(String[] args) {
		TV tv = new TV();
		Refigerator r = new Refigerator();
		
		tv.setSerial("12345");
		tv.setTitle("SAMSUNGTV");
		tv.setPrice(1000000);
		tv.setQuantity(1);
		tv.setInch(40);
		tv.setType("LCD");
		System.out.println(tv);
		
		r.setSerial("84532");
		r.setTitle("LG냉장고");
		r.setPrice(1300000);
		r.setQuantity(1);
		r.setVolume("20L");
		System.out.println(r);
	}
}