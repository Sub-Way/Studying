
public class Refigerator {
	String serial = "";
	String title = "";
	int price = 0;
	int quantity = 0;
	String volume = "";
	
	public void setSerial(String serial) {
		this.serial = serial;
	}

	public String getSerial() {
		return serial;
	}

	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	public int getPrice() {
		return price;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public int getQuantity() {
		return quantity;
	}

	public void setVolume(String volume) {
		this.volume = volume;
	}
	
	public String getVolume() {
		return volume;
	}	

	public String toString() {
		String str = serial + "	| " + title + "	| " + price + "	| " + quantity + "	| " + volume;
		return str;
	}
}
