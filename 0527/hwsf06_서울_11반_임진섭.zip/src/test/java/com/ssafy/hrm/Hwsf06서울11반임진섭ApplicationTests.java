package com.ssafy.hrm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hwsf06서울11반임진섭ApplicationTests {

	@Test
	void contextLoads() {
	}

}
