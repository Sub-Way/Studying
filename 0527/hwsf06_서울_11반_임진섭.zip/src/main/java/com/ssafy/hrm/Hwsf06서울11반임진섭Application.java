package com.ssafy.hrm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hwsf06서울11반임진섭Application {

	public static void main(String[] args) {
		SpringApplication.run(Hwsf06서울11반임진섭Application.class, args);
	}

}
