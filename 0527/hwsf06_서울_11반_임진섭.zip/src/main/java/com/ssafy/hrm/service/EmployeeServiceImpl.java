package com.ssafy.hrm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.hrm.dao.EmployeeDAO;
import com.ssafy.hrm.dto.Employee;


@Service
public class EmployeeServiceImpl implements EmployeeService {
	
    @Autowired
	private EmployeeDAO employeeDao;

    @Override
	public List<Employee> findAllEmployees() throws Exception {
		return employeeDao.findAllEmployees();
	}
    
  	@Override
	public int addEmployee(Employee emp) throws Exception {
		return employeeDao.addEmployee(emp);
	}


	@Override
	public Employee findEmployeeById(int id) throws Exception {
		return employeeDao.findEmployeeById(id);
	}

	@Override
	@Transactional
	public boolean updateEmployee(Employee emp) throws Exception {
		return employeeDao.updateEmployee(emp);
	}

	@Override
	@Transactional
	public boolean deleteEmployee(int id) throws Exception {
		return employeeDao.deleteEmployee(id);
	}

	
}
