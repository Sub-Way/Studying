package com.ssafy.hrm.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.hrm.dto.Employee;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO{

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public List<Employee> findAllEmployees() throws Exception {
		return sqlSession.selectList("s_emp.findAllEmployees");
	}
	

	@Override
	public int addEmployee(Employee emp) throws Exception {
		return sqlSession.insert("s_emp.addEmployee",emp);
	}


	@Override
	public Employee findEmployeeById(int id) throws Exception {
		System.out.println(">>>>"+sqlSession.selectOne("s_emp.findEmployeeById",id));
		return sqlSession.selectOne("s_emp.findEmployeeById",id);
	}

	@Override
	public boolean updateEmployee(Employee emp) throws Exception {
		 sqlSession.update("s_emp.updateEmployee",emp);
		 return true;
	}

	@Override
	public boolean deleteEmployee(int id) throws Exception {
		sqlSession.delete("s_emp.deleteEmployee",id);
		 return true;
	}

	
}
