import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class 다항식계산 {
	static int n,m;
	static int[] t;
	static int[] a;
	static int[] b;
	static int[] marr;
	static long[] func;

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int test = Integer.parseInt(br.readLine());

		for (int tc = 1; tc <= test; tc++) {
			n = Integer.parseInt(br.readLine()); // n번까지 계산
			t = new int[n+1];
			a = new int[n+1];
			b = new int[n+1];

			for (int i = 2; i <= n; i++) {
				StringTokenizer st = new StringTokenizer(br.readLine(), " ");
				t[i] = Integer.parseInt(st.nextToken());
				a[i] = Integer.parseInt(st.nextToken());
				b[i] = Integer.parseInt(st.nextToken());
			} // end of n

			m = Integer.parseInt(br.readLine()); // n번째의 계산해야 할 변수들 개수
			marr = new int[m]; // 변수들 개수 저장할 배열

			StringTokenizer st = new StringTokenizer(br.readLine(), " ");
			for (int i = 0; i < m; i++) {
				marr[i] = Integer.parseInt(st.nextToken());
			} // 변수 저장
			
			System.out.print("#" + tc + " ");
			for (int i = 0; i < marr.length; i++) {
				func = new long[n+1];
				func[0] = 1;
				for (int j = 1; j <= n; j++) {
					if (j == 1) {
						func[j] = marr[i];
					} else {
						if (t[j] == 1) {
							func[j] = ((func[a[j]] % 998244353) + (func[b[j]] % 998244353)) % 998244353;
						} else if (t[j] == 2) {
							func[j] = ((a[j] % 998244353) * (func[b[j]] % 998244353)) % 998244353;
						} else if (t[j] == 3) {
							func[j] = ((func[a[j]] % 998244353) * (func[b[j]] % 998244353)) % 998244353;
						}
					}
					if(j == n) {
						System.out.print(func[j] + " ");
					}
				} // end of n
			} // end of m
			System.out.println();
		} // end of tc

	}

} // end of clas
