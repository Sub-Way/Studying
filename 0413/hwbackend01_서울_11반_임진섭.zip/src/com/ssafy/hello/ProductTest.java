package com.ssafy.hello;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/product.do")
public class ProductTest extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. data get
		String productname = request.getParameter("productname");
		int productprice = Integer.parseInt(request.getParameter("productprice"));
		String productcomm = request.getParameter("productcomm");
		response.setContentType("text/html;charset=utf-8");
		
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("	<body>");
		out.println(productname + "의 가격은" + productprice + "원 입니다. 설명은 아래와 같습니다." + "<br>");
		out.print(productcomm);
		out.println("	</body>");
		out.println("</html>");
	}
}
