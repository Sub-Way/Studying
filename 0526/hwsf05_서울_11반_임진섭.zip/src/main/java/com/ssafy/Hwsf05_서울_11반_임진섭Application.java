package com.ssafy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hwsf05_서울_11반_임진섭Application {

	public static void main(String[] args) {
		SpringApplication.run(Hwsf05_서울_11반_임진섭Application.class, args);
	}

}
