package com.ssafy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hwsf05_서울_11반_임진섭ApplicationTests {

	@Test
	void contextLoads() {
	}

}
