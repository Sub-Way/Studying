package com.ssafy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hws05서울11반임진섭ApplicationTests {

	@Test
	void contextLoads() {
	}

}
