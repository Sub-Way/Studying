import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class hwalgo0513_서울_11반_임진섭 {
	public static void main(String[] args) throws IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		StringTokenizer st = new StringTokenizer(br.readLine(), " ");

		int n = Integer.parseInt(st.nextToken());
		int m = Integer.parseInt(st.nextToken());

		int[] arr = new int[n];
		LinkedList<Integer>[] graph = new LinkedList[n];
		for (int i = 0; i < n; i++) {
			graph[i] = new LinkedList<>();
		}

		for (int i = 0; i < m; i++) {
			st = new StringTokenizer(br.readLine(), " ");
			int a = Integer.parseInt(st.nextToken()) - 1;
			int b = Integer.parseInt(st.nextToken()) - 1;
			graph[a].add(b);
			arr[b]++;
		}

		Queue<Integer> sq = new LinkedList<>(); 
		Queue<Integer> rq = new LinkedList<>(); 

		for (int i = 0; i < n; i++)
			if (arr[i] == 0)
				sq.offer(i);

		while (!sq.isEmpty()) {

			int zero = sq.poll();
			rq.offer(zero);

			for (int linkedNode : graph[zero]) {
				arr[linkedNode]--;
				if (arr[linkedNode] == 0)
					sq.offer(linkedNode);
			}
		}

		StringBuilder sb = new StringBuilder();
		while (!rq.isEmpty())
			sb.append(rq.poll() + 1 + " ");
		
		
		System.out.println(sb);
	} // end of main
} // end of class
