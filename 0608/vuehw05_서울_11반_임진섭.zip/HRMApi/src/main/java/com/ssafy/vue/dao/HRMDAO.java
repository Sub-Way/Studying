package com.ssafy.vue.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssafy.vue.dto.HRM;
@Mapper
public interface HRMDAO {
	public List<HRM> selectBoard();
	public int insertBoard(HRM hrm);
	public HRM selectBoardByNo(int no);
	public int deleteBoard(int no);
}