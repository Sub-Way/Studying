package com.ssafy.vue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.vue.dto.HRM;
import com.ssafy.vue.dao.HRMDAO;

@Service
public class HRMServiceImpl implements HRMService {
	
    @Autowired
	private HRMDAO hrmDao;

    @Override
	public List<HRM> retrieveBoard() {
		return hrmDao.selectBoard();
	}
    
  	@Override
	public boolean writeBoard(HRM hmr) {
		return hrmDao.insertBoard(hmr) == 1;
	}

	@Override
	@Transactional
	public HRM detailBoard(int no) {
		return hrmDao.selectBoardByNo(no);
	}

	@Override
	@Transactional
	public boolean deleteBoard(int no) {
		return hrmDao.deleteBoard(no) == 1;
	}

}