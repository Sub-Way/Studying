package com.ssafy.vue.service;

import java.util.List;

import com.ssafy.vue.dto.HRM;

public interface HRMService {
	public List<HRM> retrieveBoard();
	public boolean writeBoard(HRM hrm);
	public HRM detailBoard(int no);
	public boolean deleteBoard(int no);
}
