

public class BAEKJOON_1436_영화감독숌 {

}
