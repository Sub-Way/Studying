import java.util.Arrays;
import java.util.Scanner;

public class BAEKJOON_2991_사나운개 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int a = sc.nextInt(); // 공격적 시간
		int b = sc.nextInt(); // 쉬는 시간
		int c = sc.nextInt(); // 공격적 시간
		int d = sc.nextInt(); // 쉬는 시간

		int p = sc.nextInt(); // 우체부 도착 시간
		int m = sc.nextInt(); // 우유배달원 도착 시간
		int n = sc.nextInt(); // 신문배달원 도착 시간

		int[] check = new int[1000];
		int max = Math.max(p, Math.max(m, n));
		
		for (int i = 1; i <= max; i += a + b) {
			for (int j = i; j < i + a; j++) {
				check[j] = 1;
			}
		}

		for (int i = 1; i <= max; i += c + d) {
			for (int j = i; j < i + c; j++) {
				if (check[j] == 1)
					check[j] = 2;
				else
					check[j] = 1;
			}
		}

		//System.out.println(Arrays.toString(check));

		System.out.println(check[p]);
		System.out.println(check[m]);
		System.out.println(check[n]);

	}
}
