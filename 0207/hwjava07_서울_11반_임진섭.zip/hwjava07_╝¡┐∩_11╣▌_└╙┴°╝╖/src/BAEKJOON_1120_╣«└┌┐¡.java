import java.util.Scanner;

public class BAEKJOON_1120_문자열 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String a = sc.next();
		String b = sc.next();

		int dif = b.length() - a.length();
		int temp = 51;
		for (int i = 0; i <= dif; i++) {
			int cnt = 0;
			for (int j = 0; j < a.length(); j++) {
				if (a.charAt(j) != b.charAt(i + j)) {
					cnt++;
				}
			}
			if (temp > cnt)
				temp = cnt;
		}
		System.out.println(temp);
	} // end of main
} // end of class
