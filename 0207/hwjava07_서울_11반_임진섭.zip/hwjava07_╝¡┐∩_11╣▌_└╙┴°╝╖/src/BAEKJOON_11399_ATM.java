

public class BAEKJOON_11399_ATM {

}
