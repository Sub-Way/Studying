

public class BAEKJOON_14501_퇴사 {

}
