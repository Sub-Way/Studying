package hwjava7_서울_11반_임진섭;

public class BAEKJOON_14501_퇴사 {

}
