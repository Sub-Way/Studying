package hwjava7_서울_11반_임진섭;

public class BAEKJOON_2991_사나운개 {

}
