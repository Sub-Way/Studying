package xml;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;
/*
 * XML Parser : XML 문서를 해독하고 유효한 데이터를 뽑아오는 과정.
 *  - XML의 문법 확인 -> XML 태그와 데이터를 분리 -> 데이터를 애플리케이션이 사용 가능하게 구조화.
 *  - XML 문서 -> XML Parser -> VO (DTO) -> 자바 프로그램으로 전달.
*/
/*
 * Document Object Model
 *  - XML 데이터 접근이 편리 -> XML 데이터 생성과 편집에 유리함.
 *  - 메모리 사용율이 높고, 파싱 속도가 느리다.
 *  - XML 문서의 전체 데이터가 필요한 경우, XML 문서에 대해서 구조적인 접근이 필요한 경우,
 *    XML 문서를 새로 만들거나 전체적인 수정이 필요한 경우에 사용함. 
*/
/*
 * javax.xml.parsers.DocumentBuilderFactory -> newInstance(), newDocumentBuilder()
 * javax.xml.parsers.DocumentBuilder -> parse()
 * org.w3c.dom.Document : 파싱된 XML 문서를 저장 및 데이터에 접근 메소드가 선언된 인터페이스.
*/

public class Xml1Dom1 {

	public static void main(String[] args) {

		Document docObj = null;
		try {
			String xmlFile = new File(".").getCanonicalPath()+"/src/xml/employees.xml";
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			docObj = builder.parse(xmlFile);
			System.out.println("docObj : " + docObj + " : What???");
		} catch(ParserConfigurationException e) {
			e.printStackTrace();
		} catch(SAXException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}

	}//main

}
