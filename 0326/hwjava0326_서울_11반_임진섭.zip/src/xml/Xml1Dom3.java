package xml;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
/*
 * org.w3c.dom.Node
 * - ATTRIBUTE_NODE
 * - CDATA_SECTION_NODE 
 * - COMMENT_NODE :
 * - DOCUMENT_NODE 
 * - ELEMENT_NODE
 * - ENTITY_NODE
 * - NOTATION_NODE
 * - TEXT_NODE
*/

public class Xml1Dom3 {

	public static void main(String[] args) {

		Document docObj = null;
		try {
			String xmlFile = new File(".").getCanonicalPath()+"/src/xml/employees.xml";
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			docObj = builder.parse(xmlFile);
			//System.out.println("docObj : " + docObj + " : What???");
			String tagName = "Employee";
			NodeList nodeList = docObj.getElementsByTagName(tagName);
			//System.out.println("nodeList : " + nodeList);
			//System.out.println("nodeList.getLength() : " + nodeList.getLength());
			for (int i = 0; i < nodeList.getLength(); i++) {
				NamedNodeMap attrMap = nodeList.item(i).getAttributes();
				for (int j = 0; j < attrMap.getLength(); j++) {
					Node node = attrMap.item(j);
					System.out.println("Attr : " + node.getNodeName()
										+ ", Value : " + node.getNodeValue());
				}
			}
		} catch(ParserConfigurationException e) {
			e.printStackTrace();
		} catch(SAXException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}

	}//main

}
