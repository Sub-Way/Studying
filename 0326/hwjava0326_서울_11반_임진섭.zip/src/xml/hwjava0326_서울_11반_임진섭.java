package xml;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
/*
 * org.w3c.dom.Node
 * - ATTRIBUTE_NODE
 * - CDATA_SECTION_NODE 
 * - COMMENT_NODE :
 * - DOCUMENT_NODE 
 * - ELEMENT_NODE
 * - ENTITY_NODE
 * - NOTATION_NODE
 * - TEXT_NODE
*/
public class hwjava0326_서울_11반_임진섭 {

	public static void main(String[] args) {

		Document docObj = null;
		try {
			String xmlFile = new File(".").getCanonicalPath()+"/src/xml/AptDealHistory.xml";
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			docObj = builder.parse(xmlFile);
			String apt = "아파트";
			NodeList aptList = docObj.getElementsByTagName(apt);
			String dong = "법정동";
			NodeList dongList = docObj.getElementsByTagName(dong);
			String money = "거래금액";
			NodeList moneyList = docObj.getElementsByTagName(money);
			
			System.out.print("아파트 명 입력 : ");
			Scanner sc = new Scanner(System.in);
			String input = sc.next();
			for (int i = 0; i < aptList.getLength(); i++) {
				Node aptNode = aptList.item(i).getChildNodes().item(0);
				Node dongNode = dongList.item(i).getChildNodes().item(0);
				Node moneyNode = moneyList.item(i).getChildNodes().item(0);
				if (aptNode.getNodeType() != Node.TEXT_NODE
						&& aptNode.getNodeType() != Node.CDATA_SECTION_NODE) {
					continue;
				}
				String aptValue = aptNode.getNodeValue();
				String dongValue = dongNode.getNodeValue();
				String moneyValue = moneyNode.getNodeValue();
				
				if(aptValue.contains(input)){
					System.out.println("아파트명 :" + aptValue + "\t" + "| 법정동 :" + dongValue + " | 거래금액 :" + moneyValue);
				}
			}
		} catch(ParserConfigurationException e) {
			e.printStackTrace();
		} catch(SAXException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}//main
}
