package xml;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.w3c.dom.Document;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
/*
 * XML Parser : XML 문서를 해독하고 유효한 데이터를 뽑아오는 과정.
 *  - XML의 문법 확인 -> XML 태그와 데이터를 분리 -> 데이터를 애플리케이션이 사용 가능하게 구조화.
 *  - XML 문서 -> XML Parser -> VO (DTO) -> 자바 프로그램으로 전달.
*/
/*
 * Simple API for XML
 *  - 이벤트 기반 파싱 -> 수행 시간이 빠르고, 메모리 효율성이 좋은 편임.
 *  - XML 문서의 일부분만 필요하거나, XML 문서의 일부분만 수정하거나,
 *    빠른 XML 문서 파싱이 필요한 경우에 사용함. 
*/
/*
 * javax.xml.parsers.SAXParserFactory -> newInstance(), newSAXParser()
 * javax.xml.parsers.SAXParser -> parse()
 * org.xml.sax.helpers.DefaultHandler
*/
import org.xml.sax.helpers.DefaultHandler;

class HandlerExam extends DefaultHandler {
	public void startDocument() throws SAXException	{
		System.out.println("startDocument.....");
	}
	public void endDocument() throws SAXException {
		System.out.println("endDocument.....");
	}
	int i = 0;
	public void startElement(String uri, String localName, String qName, Attributes attributes)
																			throws SAXException	{
		System.out.println("startElement : " + i++);
	}
}//class

public class Xml2Sax1 {

	public static void main(String[] args) {

		Document docObj = null;
		try {
			String xmlFile = new File(".").getCanonicalPath()+"/src/xml/employees.xml";
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser parser = factory.newSAXParser();
			HandlerExam handler = new HandlerExam();
			parser.parse(xmlFile, handler);
		} catch(ParserConfigurationException e) {
			e.printStackTrace();
		} catch(SAXException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}

	}//main

}//class
