package xml;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
/*
 * org.w3c.dom.Node
 * - ATTRIBUTE_NODE
 * - CDATA_SECTION_NODE 
 * - COMMENT_NODE :
 * - DOCUMENT_NODE 
 * - ELEMENT_NODE
 * - ENTITY_NODE
 * - NOTATION_NODE
 * - TEXT_NODE
*/

public class Xml1Dom2 {

	public static void main(String[] args) {

		Document docObj = null;
		try {
			String xmlFile = new File(".").getCanonicalPath()+"/src/xml/employees.xml";
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			docObj = builder.parse(xmlFile);
			//System.out.println("docObj : " + docObj + " : What???");
			String tagName = "age";
			NodeList nodeList = docObj.getElementsByTagName(tagName);
			String tagName2 = "name";
			NodeList nodeList2 = docObj.getElementsByTagName(tagName2);
			String tagName3 = "gender";
			NodeList nodeList3 = docObj.getElementsByTagName(tagName3);
			//System.out.println("nodeList : " + nodeList);
			//System.out.println("nodeList.getLength() : " + nodeList.getLength());
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node tmpNode = nodeList.item(i).getChildNodes().item(0);
				Node tmpNode2 = nodeList2.item(i).getChildNodes().item(0);
				Node tmpNode3 = nodeList3.item(i).getChildNodes().item(0);
				if (tmpNode.getNodeType() != Node.TEXT_NODE
						&& tmpNode.getNodeType() != Node.CDATA_SECTION_NODE) {
					continue;
				}
				String nodeValue = tmpNode.getNodeValue();
				String nodeValue2 = tmpNode2.getNodeValue();
				String nodeValue3 = tmpNode3.getNodeValue();
				System.out.println("Tag : " + tagName + ", Value : " + nodeValue);
				System.out.println("Tag : " + tagName2 + ", Value : " + nodeValue2);
				System.out.println("Tag : " + tagName3 + ", Value : " + nodeValue3);
			}
		} catch(ParserConfigurationException e) {
			e.printStackTrace();
		} catch(SAXException e) {
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		}

	}//main

}
