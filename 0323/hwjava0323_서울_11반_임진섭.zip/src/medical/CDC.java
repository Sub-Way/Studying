package medical;

import java.util.List;
import java.util.Set;

import person.Patient;

public class CDC extends Organization {

	private List<Hospital> hospitalList;
	private Set<Patient> patientList;

	public CDC() {
	}

	public CDC(String name, int employeeCount, List<Hospital> hospitalList, Set<Patient> patientList) {
		super(name, employeeCount);
		this.hospitalList = hospitalList;
		this.patientList = patientList;
	}

	public List<Hospital> getHospitalList() {
		return hospitalList;
	}

	public Set<Patient> getPatientList() {
		return patientList;
	}

	public void setHospitalList(List<Hospital> hospitalList) {
		this.hospitalList = hospitalList;
	}

	public void setPatientList(Set<Patient> patientList) {
		this.patientList = patientList;
	}

	public void about() {
		System.out.println("Organization - CDC" + super.getName());
	}

	public void about(String more) {
		about();
		System.out.println("We manage Hospital and Patients");
	}

	public void addPatient(CDC cdc, Patient p) throws NotCoronaException {
		if (!p.isCorona())
			throw new NotCoronaException("NotCorona");
		cdc.getPatientList().add(p);
	}

	public void removePatient(CDC cdc, Patient p) {
		cdc.getPatientList().remove(p);
	}

}
