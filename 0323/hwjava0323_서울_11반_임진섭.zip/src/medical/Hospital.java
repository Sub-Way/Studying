package medical;

import java.util.List;

import person.Patient;

public class Hospital extends Organization implements MedicalAction{
	private String hospitalId;
	private int roomTotalCount;
	private int roomEmptyCount;
	
	public Hospital() {}
	
	public Hospital(String name, int employeeCount, String hopitalId, int roomTotalCount, int roomEmptyCount) {
		super(name, employeeCount);
		this.hospitalId = hopitalId;
		this.roomTotalCount = roomTotalCount;
		this.roomEmptyCount = roomEmptyCount;
	}
	
	public String getHospitalId() {
		return hospitalId;
	}
	
	public int getRoomTotalCount() {
		return roomTotalCount;
	}
	
	public int roomEmptyCount() {
		return roomEmptyCount;
	}
	
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	
	public void setRoomTotalCount(int roomTotalCount) {
		this.roomTotalCount = roomTotalCount;
	}
	
	public void setRoomEmptyCount(int roomEmptyCount) {
		this.roomEmptyCount = roomEmptyCount;
	}
	
	public void about(String more) {
		System.out.println("We are Hospital");
	}

	@Override
	public void addPatient(CDC cdc, Patient p) throws NotCoronaException {
		if(!p.isCorona()) throw new NotCoronaException("NotCorona");
		cdc.getPatientList().add(p);
	}

	@Override
	public void removePatient(CDC cdc, Patient p) {
		cdc.getPatientList().remove(p);
	}

	@Override
	public void wirteReport(List<Patient> pList) {
		
	}
}
