package com.ssafy.controller;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssafy.dto.Product;
import com.ssafy.service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	ProductService service;

	@RequestMapping(value = "/productSelectAll", method = RequestMethod.GET)//HttpServlet의 get 역할
	public String selectAll(Locale locale, Model model) {
		service.selectAll();
		return "home";
	}

	@RequestMapping(value = "/first", method = RequestMethod.GET)//HttpServlet의 get 역할
	public String productRegistPage() {
		return "input";
	}

	@RequestMapping(value = "/result", method = RequestMethod.GET)//HttpServlet의 get 역할
	public String productRegist(Product prdt) {
		System.out.println(prdt.getName());
		int successCnt = service.productRegist(prdt);
		return "input";
	}

}
