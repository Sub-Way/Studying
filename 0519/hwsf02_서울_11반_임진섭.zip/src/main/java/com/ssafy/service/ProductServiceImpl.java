package com.ssafy.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.dto.Product;
import com.ssafy.repositary.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo repo;//필요해:의존성 + 스프링이 나에게 줘:주입

	@Override
	public List<Product> selectAll() {
		List<Product> list = new ArrayList<Product>();
		list = repo.selectAll();
		return list;
	}

	@Override
	public int productRegist(Product prdt) {
		int successCnt = repo.productRegist(prdt);
		return 0;
	}

}
