package com.ssafy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssafy.dto.Product;

public interface ProductService {

	public List<Product> selectAll();

	public int productRegist(Product prdt);

}
