package com.ssafy.repositary;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.dto.Product;

public interface ProductRepo {

	public List<Product> selectAll();

	public int productRegist(Product prdt);

}
