package com.ssafy.repositary;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo {


	public List<Product> selectAll() {
		List<Product> list = new ArrayList<Product>();
		
		System.out.println("This is ProductRepoImpl - selectAll()");
		return list;
	}

	@Override
	public int productRegist(Product prdt) {
		System.out.println("아이디 : " + prdt.getId());
		System.out.println("상품명 : " + prdt.getName());
		System.out.println("가격 : " + prdt.getPrice());
		System.out.println("설명 : " + prdt.getDescription());
		return 1;
	}
}
