import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class hw_algo0501_서울_11반_임진섭 {
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int t = Integer.parseInt(br.readLine());

		for (int tc = 1; tc <= t; tc++) {
			String two = br.readLine();
			Long twoLen = (long) two.length();
			String three = br.readLine();
			Long thrLen = (long) three.length();

			Long result = (long)0;
			int flag = 0;
			
			for (int i = 0; i < twoLen; i++) {
				StringBuilder twoTemp = new StringBuilder();
				StringBuilder threeTemp = new StringBuilder();
				for (int j = 0; j < thrLen; j++) {
					twoTemp.append(two);
					threeTemp.append(three);
					if(twoTemp.toString().charAt(i)=='1' && threeTemp.toString().charAt(j)=='2') {
						twoTemp.replace(i, i+1,"0");
						threeTemp.replace(j, j+1,"1");
						if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
							result = Long.parseLong(twoTemp.toString(),2);
							flag = 1;
							break;
						}
						else {
							threeTemp.replace(j, j+1,"0");
							if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
								result = Long.parseLong(twoTemp.toString(),2);
								flag = 1;
								break;
							}
						}
					} else if(twoTemp.toString().charAt(i)=='1' && threeTemp.toString().charAt(j)=='1') {
						twoTemp.replace(i, i+1,"0");
						threeTemp.replace(j, j+1,"2");
						if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
							result = Long.parseLong(twoTemp.toString(),2);
							flag = 1;
							break;
						}
						else {
							threeTemp.replace(j, j+1,"0");
							if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
								result = Long.parseLong(twoTemp.toString(),2);
								flag = 1;
								break;
							}
						}
					} else if(twoTemp.toString().charAt(i)=='1' && threeTemp.toString().charAt(j)=='0') {
						twoTemp.replace(i, i+1,"0");
						threeTemp.replace(j, j+1,"1");
						if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
							result = Long.parseLong(twoTemp.toString(),2);
							flag = 1;
							break;
						}
						else {
							threeTemp.replace(j, j+1,"2");
							if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
								result = Long.parseLong(twoTemp.toString(),2);
								flag = 1;
								break;
							}
						}
					} else if(twoTemp.toString().charAt(i)=='0' && threeTemp.toString().charAt(j)=='2') {
						twoTemp.replace(i, i+1,"1");
						threeTemp.replace(j, j+1,"1");
						if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
							result = Long.parseLong(twoTemp.toString(),2);
							flag = 1;
							break;
						}
						else {
							threeTemp.replace(j, j+1,"0");
							if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
								result = Long.parseLong(twoTemp.toString(),2);
								flag = 1;
								break;
							}
						}
					} else if(twoTemp.toString().charAt(i)=='0' && threeTemp.toString().charAt(j)=='1') {
						twoTemp.replace(i, i+1,"1");
						threeTemp.replace(j, j+1,"2");
						if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
							result = Long.parseLong(twoTemp.toString(),2);
							flag = 1;
							break;
						}
						else {
							threeTemp.replace(j, j+1,"0");
							if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
								result = Long.parseLong(twoTemp.toString(),2);
								flag = 1;
								break;
							}
						}
					} else if(twoTemp.toString().charAt(i)=='0' && threeTemp.toString().charAt(j)=='0') {
						twoTemp.replace(i, i+1,"1");
						threeTemp.replace(j, j+1,"1");
						if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
							result = Long.parseLong(twoTemp.toString(),2);
							flag = 1;
							break;
						}
						else {
							threeTemp.replace(j, j+1,"2");
							if(Long.parseLong(twoTemp.toString(),2) == Long.parseLong(threeTemp.toString(),3)) {
								result = Long.parseLong(twoTemp.toString(),2);
								flag = 1;
								break;
							}
						}
					} 
					twoTemp.delete(0, twoTemp.length());
					threeTemp.delete(0, threeTemp.length());
				}
				if(flag == 1)
					break;
			}
			System.out.println("#" + tc + " " +result);
		} // end of tc
	} // end of main
} // end of class
