package com.ssafy.edu1;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class TestController {
	
	@RequestMapping(value = "/amuna1", method = RequestMethod.GET)
	public String home2(Model model) {
		model.addAttribute("name", "아무나 찾아라..." );
		return "amu1"; // 특정한 jsp 뷰를 호출
	}
	
}
