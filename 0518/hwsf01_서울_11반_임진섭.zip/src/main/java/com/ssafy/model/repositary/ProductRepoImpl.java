package com.ssafy.model.repositary;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.ssafy.model.dto.Product;

@Repository
public class ProductRepoImpl implements ProductRepo{
	
	public List<Product> selectAll(){
		List<Product> list = new ArrayList<Product>();
		System.out.println("This is ProductRepoImpl - selectAll()");
		return list;
	}

	@Override
	public Product select(String id) {
		Product product = null;
		return product;
	}

	@Override
	public int insert(Product product) {
		return 1;
	}

	@Override
	public int update(Product product) {
		return 1;
	}

	@Override
	public int delete(String id) {
		return 1;
	}
}
