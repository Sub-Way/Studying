package com.ssafy.model.test;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

public class BeanTest {

	public static void main(String[] args) {
		ProductService service = new ProductServiceImpl();
		Product product = new Product("111", "222", "333", 4444);
		System.out.println("호출 시작 : service - selectAll()");
		service.selectAll();
		System.out.println("호출 종료 : service - selectAll()");
		
		System.out.println("호출 시작 : service - select()");
		service.select(product.getId());
		System.out.println("호출 종료 : service - select()");
		
		System.out.println("호출 시작 : service - insert()");
		service.insert(product);
		System.out.println("호출 종료 : service - insert()");
		
		System.out.println("호출 시작 : service - update()");
		service.update(product);
		System.out.println("호출 종료 : service - update()");
		
		System.out.println("호출 시작 : service - delete()");
		service.delete(product.getId());
		System.out.println("호출 종료 : service - delete()");
	}

}
