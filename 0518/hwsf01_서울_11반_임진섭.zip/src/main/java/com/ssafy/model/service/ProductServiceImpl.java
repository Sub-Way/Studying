package com.ssafy.model.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repositary.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductRepo repo; // 필요해:의존성 + 스프링이 나에게 줘:주입
	
	@Override
	public List<Product> selectAll() {
		List<Product> list = new ArrayList<Product>();
		//list = repo.selectAll();
		return list;
	}

	@Override
	public Product select(String id) {
		Product product = null;
		return product;
	}

	@Override
	public int insert(Product product) {
		return 1;
	}

	@Override
	public int update(Product product) {
		return 1;
	}

	@Override
	public int delete(String id) {
		return 1;
	}
}
